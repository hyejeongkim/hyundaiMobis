package aes.sample.test.biz.authority;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.handler.AbstractHandlerExceptionResolver;

/**
 * <pre>
 * 권한 및 인증 오류시 예외처리를 위한 ExceptionResolver이다.
 * </pre>
 * 
 * @ClassName : AuthorityExceptionResolver.java
 * @author Park SeongMin
 * @since 2016. 4. 5.
 * @version 1.0
 * @see
 * @Modification Information
 * 
 *               <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2016. 4. 5.     Park SeongMin     최초 생성
 * </pre>
 */

public class AuthorityExceptionResolver extends AbstractHandlerExceptionResolver {

    @Override
    protected ModelAndView doResolveException(HttpServletRequest request, HttpServletResponse response, Object handler,
            Exception ex) {
        
        // interceptor 혹은 service에서 AuthorityException을 throw 할 경우 처리된다. 
        if (ex instanceof AuthorityException) {
            UnAuthorizedView view = new UnAuthorizedView();
            ModelAndView modelAndView = new ModelAndView(view);
            return modelAndView;
        }

        return null;
    }

}
