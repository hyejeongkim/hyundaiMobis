package aes.sample.test.biz.web;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import able.com.ui.adaptor.annotation.ParamDataSet;
import able.com.ui.adaptor.nexacro.data.NexacroResult;
import able.com.vo.HMap;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.nexacro.xapi.data.DataSet;

import aes.sample.test.biz.service.PilotService;
import aes.sample.test.biz.vo.PilotVO;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName : PilotController.java
 * @Description : 클래스 설명을 기술합니다.
 * @author JCH
 * @since 2017. 7. 10.
 * @version 1.0
 * @see
 * @Modification Information
 * 
 *               <pre>
 *     since          author              description 
 *  ===========    =============    ===========================
 *  2017. 7. 10.     JCH     	최초 생성
 *               </pre>
 */
@Controller
public class PilotController {
    @Autowired
    private PilotService pilotService;

    /*@RequestMapping(value = "searchUserList.do", method = RequestMethod.POST)
    public NexacroResult searchUserList(@ParamDataSet(name = "ds_search") PilotVO searchVo) throws Exception{
        List<PilotVO> pilotList = pilotService.searchUserList(searchVo);

        NexacroResult result = new NexacroResult();
        result.addDataSet("output1", pilotList);

        return result;
    }*/
    
    @RequestMapping(value = "searchUserList.do", method = RequestMethod.POST)
    public NexacroResult searchUserList(@ParamDataSet(name = "ds_search") Map searchMap
            , NexacroResult result) throws Exception{
        
        List<HMap> pilotList = pilotService.searchUserList(searchMap);

        result.addDataSet("output1", pilotList);

        return result;
    }
    
    @RequestMapping(value = "searchUserVOList.do", method = RequestMethod.POST)
    public NexacroResult searchUserVOList(@ParamDataSet(name = "ds_search") Map searchMap
            , NexacroResult result) throws Exception{
        
        List<PilotVO> pilotList = pilotService.searchUserVOList(searchMap);

        result.addDataSet("output1", pilotList);

        return result;
    }

    @RequestMapping(value="selectUserInfo.do", method=RequestMethod.POST)
    public NexacroResult selectUserInfo(@ParamDataSet(name = "ds_search") List<Map> searchMap
            , NexacroResult result) throws Exception{
        
        List<HMap> pilotList = pilotService.searchUserList(searchMap.get(0));

        result.addDataSet("output1", pilotList);

        return result;
    }

    @RequestMapping(value = "saveUserInfo.do", method = RequestMethod.POST)
    public NexacroResult saveUserInfo(@ParamDataSet(name = "ds_dataInfo") List<Map> saveMap
            , NexacroResult result) throws Exception{
        int resCnt = 0;

        resCnt = pilotService.saveUserInfo(saveMap);

        DataSet ds = new DataSet();
        ds.addConstantColumn("resCnt", resCnt);

        HashMap<String, String> resMap = new HashMap<String, String>();
        resMap.put("resCnt", resCnt + "");

        ds.setName("ds_result");
        result.addDataSet(ds);

        return result;
    }
    

    @RequestMapping(value = "deleteUserInfo.do", method = RequestMethod.POST)
    public NexacroResult deleteUserInfo(@ParamDataSet(name = "ds_dataInfo") List<Map> deleteMap
            , NexacroResult result) throws Exception{
        int resCnt = 0;

        resCnt = pilotService.saveUserInfo(deleteMap);

        DataSet ds = new DataSet();
        ds.addConstantColumn("resCnt", resCnt);

        HashMap<String, String> resMap = new HashMap<String, String>();
        resMap.put("resCnt", resCnt + "");


        ds.setName("ds_result");
        result.addDataSet(ds);

        return result;
    }

    @RequestMapping(value = "saveUserList.do", method = RequestMethod.POST)
    public NexacroResult saveUserList(@ParamDataSet(name = "ds_listInfo") List<Map> searchVOList
            , NexacroResult result) throws Exception{
        int resCnt = pilotService.saveUserList(searchVOList);

        DataSet ds = new DataSet();
        ds.addConstantColumn("resCnt", resCnt);

        HashMap<String, String> resMap = new HashMap<String, String>();
        resMap.put("resCnt", resCnt + "");


        ds.setName("ds_result");
        result.addDataSet(ds);

        return result;
    }
}
