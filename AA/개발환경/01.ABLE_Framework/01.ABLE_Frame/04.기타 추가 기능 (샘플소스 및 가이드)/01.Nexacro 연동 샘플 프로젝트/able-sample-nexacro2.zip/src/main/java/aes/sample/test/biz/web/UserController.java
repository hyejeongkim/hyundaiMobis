package aes.sample.test.biz.web;


import java.util.List;

import javax.annotation.Resource;

import able.com.ui.adaptor.annotation.ParamDataSet;
import able.com.ui.adaptor.annotation.ParamVariable;
import able.com.web.HController;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import able.com.ui.adaptor.nexacro.data.NexacroResult;
import com.nexacro.xapi.data.PlatformData;

import aes.sample.test.biz.service.UserService;
import aes.sample.test.biz.vo.DefaultVO;
import aes.sample.test.biz.vo.UserVO;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName   : UserController.java
 * @Description : 클래스 설명을 기술합니다.
 * @author Autoever
 * @since 2017. 10. 31.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2017. 10. 31.     Autoever     	최초 생성
 * </pre>
 */
@Controller
public class UserController extends HController {

    // @Autowired(required = false) // Type 정의
    @Resource(name = "userService")
    // Name 정의
    private UserService userService;
    
    /**
     * 사용자 정보를 조회한다.
     * Statements
     *
     * @param searchVO
     * @param platformData
     * @param result
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/selectUserVOList.do")
    public NexacroResult selectUserVOList(@ParamDataSet(name="ds_search") DefaultVO searchVO
                            , PlatformData platformData, NexacroResult result) throws Exception{
        
        List<UserVO> userList = userService.selectUserVOList(searchVO);
        
        result.addDataSet("output1", userList);
        
        return result;
    }
    
    /**
     * 사용자 상세 정보를 조회한다.
     * Statements
     *
     * @param userId
     * @param platformData
     * @param result
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/selectUserVO.do")
    public NexacroResult selectUserVO(@ParamVariable(name="userId") String userId
                            , PlatformData platformData, NexacroResult result) throws Exception{
        
        UserVO userList = userService.selectUserVO(userId);
        
        result.addDataSet("output1", userList);
        
        return result;
    }
    
    /**
     * 사용자 정보 한건 수정
     * Statements
     *
     * @param userVO
     * @param platformData
     * @param result
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/updateUserVO.do")
    public NexacroResult updateUserVO(
                            @ParamDataSet(name="input1") UserVO userVO
                            , PlatformData platformData, NexacroResult result) throws Exception{
        
        userService.updateUserVO(userVO);
        
        return result;
    }
    
    /**
     * 사용자 신규 한건 등록
     * Statements
     *
     * @param userVO
     * @param platformData
     * @param result
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/insertUserVO.do")
    public NexacroResult insertUserVO(
                            @ParamDataSet(name="input1") UserVO userVO
                            , PlatformData platformData, NexacroResult result) throws Exception{
        
        userService.insertUserVO(userVO);
        
        return result;
    }
    
    /**
     * 사용자 한건 삭제
     * Statements
     *
     * @param userId
     * @param platformData
     * @param result
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/deleteUserVO.do")
    public NexacroResult deleteUserVO(
                            @ParamVariable(name="userId") String userId
                            , PlatformData platformData, NexacroResult result) throws Exception{
        
        userService.deleteUserVO(userId);
        
        return result;
    }
    
    /**
     * 사용자 정보 한건 수정 (등록/수정/삭제)
     * Statements
     *
     * @param userVO
     * @param platformData
     * @param result
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/multiUserVO.do")
    public NexacroResult multiUserVO(
                            @ParamDataSet(name="input1") UserVO userVO
                            , PlatformData platformData, NexacroResult result) throws Exception{
        
        userService.multiUserVO(userVO);
        
        return result;
    }
    
    /**
     * 사용자 정보 여러건 한꺼번에 수정(등록/수정/삭제)
     * Statements
     *
     * @param userVO
     * @param platformData
     * @param result
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/multiUserVOList.do")
    public NexacroResult multiUserVOList(
                            @ParamDataSet(name="input1") List<UserVO> userVO
                            , PlatformData platformData, NexacroResult result) throws Exception{
        
        userService.multiUserVOList(userVO);
        
        return result;
    }
 
    
}
