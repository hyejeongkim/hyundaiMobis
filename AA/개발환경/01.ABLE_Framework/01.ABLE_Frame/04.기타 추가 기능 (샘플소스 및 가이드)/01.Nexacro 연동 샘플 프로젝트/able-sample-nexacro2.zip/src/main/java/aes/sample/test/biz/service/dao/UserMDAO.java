package aes.sample.test.biz.service.dao;

import java.util.List;

import org.springframework.stereotype.Repository;

import able.com.mybatis.Mapper;
import able.com.ui.adaptor.nexacro.dao.mybatis.NexacroHsqlAbstractDAO;

import aes.sample.test.biz.vo.DefaultVO;
import aes.sample.test.biz.vo.UserVO;

/**
 * <pre>
 * Test를 위한 DAO Sample Class
 * </pre>
 * 
 * @ClassName   : SampleDAO.java
 * @Description : Sample DAO Class
 * @author djkim
 * @since 2012. 1. 31.
 * @version 1.0
 * @see
 * @Modification Information
 * 
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2012. 1. 31.     djkim     최초 생성
 * </pre>
 */
@Mapper("userMDAO")
public interface UserMDAO {

    public List<UserVO> selectUserVOList(DefaultVO searchVO) throws Exception;
    
    public UserVO selectUserVO(String userId) throws Exception;

    public int insertUserVO(UserVO user) throws Exception;
    
    public int updateUserVO(UserVO user) throws Exception;
    
    public int deleteUserVO(String userId) throws Exception;

}
