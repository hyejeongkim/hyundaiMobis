package aes.sample.test.biz.service;

import java.util.List;
import java.util.Map;

import able.com.vo.HMap;

import aes.sample.test.biz.vo.PilotVO;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName   : PilotService.java
 * @Description : 클래스 설명을 기술합니다.
 * @author JCH
 * @since 2017. 7. 10.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2017. 7. 10.     JCH     	최초 생성
 * </pre>
 */

public interface PilotService {
    public List<HMap> searchUserList(Map searchMap) throws Exception;
    public List<PilotVO> searchUserVOList(Map searchMap) throws Exception;
    public PilotVO selectUserInfo(PilotVO pilotVO) throws Exception;
    public int saveUserInfo(List<Map> saveMap) throws Exception;
    public int saveUserList(List<Map> saveMapList) throws Exception;
}

