﻿/************************************************************************************************************
---- 기능 확장  XJS (Dataset)

1. extIsUpdate            -- Dataset이 Insert/Modify/Delete 되었는지 체크
2. extFindRowArray        -- Dataset에서 expr에 맞는 모든 Row Index를 찾아 배열로 리턴한다.

3. extKeystring           -- sort와 keystring 를 동시에 사용 하때 set_keystring를 사용  하지 않고 extKeystring 를 사용 한다
                             주의 : keystring를 사용 하여 Group 할경우 해당 Group로 Sort 시에만 사용 해야 한다

4. extGetOrgRow           -- 그룹핑 되어 있을 경우 소계 로우를 제외한 로우 표시
5. extAddRow              -- 데이타셋의 row를 추가 하며 추가  한 데이타셋의컬럼중 String 타입 컬럼에 empty("") 값을 넣어 준다
5. extResetRow            -- 수정된 Row를 original 데이타로 원복한다.
6.gfn_clearSortMark       -- Sort Mark 제거
*************************************************************************************************************/

// 데이타셋 기능 확장 API
this.datasetExp = {
	/********************************************************************************
	 * Function Name    : extIsUpdate
	 * Desc             : Dataset이 Insert/Modify/Delete 되었는지 체크
	 * Parameter        :
	 * Return           :
	 ********************************************************************************/
    extIsUpdate : function () {
        var ds = this, returnVal = false;
		if (ds.getDeletedRowCount() > 0 || ds.findRowExpr("dataset.getRowType(rowidx)==4||dataset.getRowType(rowidx)==2||dataset.getRowType(rowidx)==8") > -1) {
			returnVal = true;
		}
		
		return returnVal;
    },     
    
	/********************************************************************************
	 * Function Name    : extFindRowArray
	 * Desc             : Dataset에서 expr에 맞는 모든 Row Index를 찾아 배열로 리턴한다.
	 * Parameter        : a_sExprText = expr 문자열
	 * Return           : Array = 입력 expr에 맞는 row index 배열
	 ********************************************************************************/    
    extFindRowArray : function (a_sExprText) {
        var ds = this, arrRetVal = new Array();

        var nFindRow = ds.findRowExpr(a_sExprText);
        if (nFindRow == -1)
            return arrRetVal;
        
        arrRetVal.push(nFindRow);
        
        for (var i = nFindRow; i<ds.getRowCount(); i++) {
            nFindRow = ds.findRowExpr(a_sExprText, i+1);
            
            if (nFindRow == -1) {
                break;
            }
            
            arrRetVal.push(nFindRow);
            i = nFindRow-1;
        }
        
        return arrRetVal;
    },
    
	/********************************************************************************
	 * Function Name    : extKeystring
	 * Desc             : sort와 keystring 를 동시에 사용 하때 set_keystring를 사용  하지 않고 extKeystring 를 사용 한다
	 * Parameter        : a_sKeystring = keystring 문자열
	 * Return           : N/A
	 ********************************************************************************/    
    extKeystring : function (a_sKeystring) {
        var ds = this;
        
        ds.set_keystring(a_sKeystring);
        ds.user_orgKeystring = a_sKeystring;
    },
    
	/********************************************************************************
	 * Function Name    : extGetOrgRow
	 * Desc             : 그룹핑 되어 있을 경우 소계 로우를 제외한 로우 표시
	 * Parameter        : a_nCurRow = Row Index
	 * Return           : int = Row Index
	 ********************************************************************************/
    extGetOrgRow : function (a_nCurRow) {
        var ds = this;
		if (ds.getRowLevel(a_nCurRow) != 0)
			return "";
		  
		return ds._viewRecords[a_nCurRow]._rawidx;
    },
    
	/********************************************************************************
	 * Function Name    : extAddRow
	 * Desc             : 데이타셋의 row를 추가 하며 추가  한 데이타셋의컬럼중 
	 *					  String 타입 컬럼에 empty("") 값을 넣어 준다
	 * Parameter        : a_nInputRow = Row Index
	 * Return           : int = Row Index
	 ********************************************************************************/    
    extAddRow : function (a_nInputRow) {
        var ds = this;        
        var nRow = ds.addRow();
        
        for (var i =0; i<ds.getColCount(); i++) {
            var oColInfo = ds.getColumnInfo(i);
            var sType = oColInfo.type;
            
            if (sType.toUpperCase() == "STRING") {
                ds.setColumn(nRow, ds.getColID(i), "");
            }    
        }
        
        return nRow;
    },
    
	/********************************************************************************
	 * Function Name    : extResetRow
	 * Desc             : 수정된 Row를 original 데이타로 원복한다.
	 * Parameter        : a_nRetsetRow = 원복할 Row Index
	 *					  a_bEnableEvent = 원복시 이벤트를 발생시킬것인가 여부, 생략시 true
	 * Return           : int = Row Index
	 ********************************************************************************/ 
    extResetRow : function (a_nRetsetRow, a_bEnableEvent) {
        var ds = this;
        var arrTargetRow = [];
        
        if (a_nRetsetRow instanceof Array) {
            arrTargetRow = a_nRetsetRow;
        } 
        else {
            arrTargetRow.push(a_nRetsetRow);
        }
        
        if (!a_bEnableEvent)
            ds.set_enableevent(false);
        
        for (var j=0; j<arrTargetRow.length; j++) {
            var nRow = arrTargetRow[j];
            
			for (var i=0; i<ds.getColCount();  i++) {
		        var sColId = ds.getColID(i);
		       
		        if (ds.getColumn(nRow, sColId) != ds.getOrgColumn(nRow, sColId)) {
		            ds.setColumn(nRow, sColId, ds.getOrgColumn(nRow, sColId));		            
		        }
			}
        }
        
        if (!a_bEnableEvent)
            ds.set_enableevent(true);
        
        return true;
    }
}

this.addDsExt = function ()
{
    for (var a in  this.datasetExp)
	{
		nexacro.Dataset.prototype[a] = this.datasetExp[a];
	}
}

this.addDsExt();

// Combo 기능 확장 API
this.comboExp = {
    
}