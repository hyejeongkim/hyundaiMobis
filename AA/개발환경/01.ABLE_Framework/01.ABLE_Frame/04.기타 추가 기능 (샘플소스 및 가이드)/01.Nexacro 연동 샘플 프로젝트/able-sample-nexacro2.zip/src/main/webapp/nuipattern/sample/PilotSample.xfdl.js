﻿(function()
{
    return function()
    {
        if (!this._is_form)
            return;
        
        this.on_create = function()
        {
            // Declare Reference
            var obj = null;
            
            if (Form == this.constructor) {
                this.set_name("form");
                this.set_classname("CodeMgmt");
                this.set_titletext("공통코드관리");
                this._setFormPosition(0,0,800,422);
            }
            this.getSetter("inheritanceid").set("");

            
            // Object(Dataset, ExcelExportObject) Initialize
            obj = new Dataset("ds_listInfo", this);
            obj.set_firefirstcount("0");
            obj.getSetter("firenextcount").set("0");
            obj.set_useclientlayout("true");
            obj.set_updatecontrol("true");
            obj.set_enableevent("true");
            obj.set_loadkeymode("keep");
            obj.set_loadfiltermode("keep");
            obj.set_reversesubsum("false");
            obj._setContents("<ColumnInfo><Column id=\"chk\" type=\"STRING\" size=\"10\"/><Column id=\"no\" type=\"INT\" size=\"20\"/><Column id=\"userId\" type=\"STRING\" size=\"100\"/><Column id=\"userName\" type=\"STRING\" size=\"256\"/><Column id=\"email\" type=\"STRING\" size=\"20\"/><Column id=\"cellPhone\" type=\"STRING\" size=\"20\"/></ColumnInfo><Rows><Row/><Row/><Row><Col id=\"userId\">&gt;</Col></Row><Row/><Row/></Rows>");
            this.addChild(obj.name, obj);

            obj = new Dataset("ds_dataInfo", this);
            obj.set_firefirstcount("0");
            obj.getSetter("firenextcount").set("0");
            obj.set_useclientlayout("true");
            obj.set_updatecontrol("true");
            obj.set_enableevent("true");
            obj.set_loadkeymode("keep");
            obj.set_loadfiltermode("keep");
            obj.set_reversesubsum("false");
            obj._setContents("<ColumnInfo><Column id=\"userId\" type=\"STRING\" size=\"256\"/><Column id=\"userName\" type=\"STRING\" size=\"256\"/><Column id=\"enName\" type=\"STRING\" size=\"256\"/><Column id=\"cellPhone\" type=\"STRING\" size=\"256\"/><Column id=\"company\" type=\"STRING\" size=\"256\"/><Column id=\"jobPosition\" type=\"STRING\" size=\"256\"/><Column id=\"officerYn\" type=\"STRING\" size=\"256\"/><Column id=\"compZipCode\" type=\"STRING\" size=\"256\"/><Column id=\"compAddress\" type=\"STRING\" size=\"256\"/><Column id=\"email\" type=\"STRING\" size=\"256\"/><Column id=\"deptId\" type=\"STRING\" size=\"256\"/><Column id=\"password\" type=\"STRING\" size=\"256\"/><Column id=\"birthDay\" type=\"DATE\" size=\"256\"/></ColumnInfo>");
            this.addChild(obj.name, obj);

            obj = new Dataset("ds_search", this);
            obj.set_firefirstcount("0");
            obj.getSetter("firenextcount").set("0");
            obj.set_useclientlayout("false");
            obj.set_updatecontrol("true");
            obj.set_enableevent("true");
            obj.set_loadkeymode("keep");
            obj.set_loadfiltermode("keep");
            obj.set_reversesubsum("false");
            obj._setContents("<ColumnInfo><ConstColumn id=\"pageIndex\" type=\"INT\" size=\"30\" value=\"1\"/><ConstColumn id=\"pageSize\" type=\"INT\" size=\"30\" value=\"5\"/><ConstColumn id=\"pageUnit\" type=\"INT\" size=\"30\" value=\"5\"/><Column id=\"searchKeyword\" type=\"STRING\" size=\"100\"/><Column id=\"searchCondition\" type=\"STRING\" size=\"100\"/></ColumnInfo><Rows><Row><Col id=\"searchCondition\"/><Col id=\"searchKeyword\">0</Col></Row></Rows>");
            this.addChild(obj.name, obj);

            obj = new Dataset("ds_combo", this);
            obj.set_firefirstcount("1");
            obj._setContents("<ColumnInfo><Column id=\"codeInfo\" type=\"STRING\" size=\"256\"/><Column id=\"nameInfo\" type=\"STRING\" size=\"256\"/></ColumnInfo><Rows><Row><Col id=\"codeInfo\">0</Col><Col id=\"nameInfo\">선택</Col></Row><Row><Col id=\"codeInfo\">ID</Col><Col id=\"nameInfo\">ID</Col></Row><Row><Col id=\"codeInfo\">NAME</Col><Col id=\"nameInfo\">NAME</Col></Row></Rows>");
            this.addChild(obj.name, obj);

            obj = new Dataset("ds_result", this);
            obj.set_useclientlayout("false");
            obj._setContents("<ColumnInfo><Column id=\"resCnt\" type=\"INT\" size=\"256\"/></ColumnInfo>");
            this.addChild(obj.name, obj);

            obj = new Dataset("ds_radio", this);
            obj._setContents("<ColumnInfo><Column id=\"codeInfo\" type=\"STRING\" size=\"256\"/><Column id=\"nameInfo\" type=\"STRING\" size=\"256\"/></ColumnInfo><Rows><Row><Col id=\"codeInfo\">Y</Col><Col id=\"nameInfo\">Y</Col></Row><Row><Col id=\"codeInfo\">N</Col><Col id=\"nameInfo\">N</Col></Row></Rows>");
            this.addChild(obj.name, obj);


            
            // UI Components Initialize
            obj = new Grid("grd_list", "absolute", "0", "63", null, "147", "0", null, this);
            obj.set_taborder("7");
            obj.set_binddataset("ds_listInfo");
            obj.set_cellsizingtype("col");
            obj.set_autofittype("col");
            obj.getSetter("domainId").set("nexa.codegroup;nexa.code.groupname;nexa.dspt;nexa.use;nexa.createdate;nexa.createuser;nexa.updatedate;nexa.updateuser");
            obj.set_createcellasync("true");
            obj._setContents("<Formats><Format id=\"default\"><Columns><Column size=\"80\"/><Column size=\"80\"/><Column size=\"80\"/><Column size=\"80\"/><Column size=\"80\"/><Column size=\"80\"/></Columns><Rows><Row band=\"head\" size=\"24\"/><Row band=\"body\" size=\"24\"/></Rows><Band id=\"head\"><Cell col=\"0\" disptype=\"normal\" text=\"chk\"/><Cell col=\"1\" disptype=\"normal\" text=\"no\"/><Cell col=\"2\" disptype=\"normal\" text=\"userId\"/><Cell col=\"3\" disptype=\"normal\" text=\"userName\"/><Cell col=\"4\" disptype=\"normal\" text=\"email\"/><Cell col=\"5\" disptype=\"normal\" text=\"cellPhone\"/></Band><Band id=\"body\"><Cell col=\"0\" disptype=\"normal\" text=\"bind:chk\"/><Cell col=\"1\" disptype=\"normal\" text=\"bind:no\"/><Cell col=\"2\" disptype=\"normal\" text=\"bind:userId\"/><Cell col=\"3\" disptype=\"normal\" text=\"bind:userName\"/><Cell col=\"4\" disptype=\"normal\" text=\"bind:email\"/><Cell col=\"5\" disptype=\"normal\" text=\"bind:cellPhone\"/></Band></Format></Formats>");
            this.addChild(obj.name, obj);

            obj = new Div("div_search", "absolute", "0", "0", null, "27", "0", null, this);
            obj.set_taborder("0");
            obj.set_text("Div00");
            obj.set_scrollbars("none");
            obj.set_cssclass("div_WF_searchBg");
            this.addChild(obj.name, obj);
            obj = new Button("btn_search", "absolute", "86.97%", "1", null, "23", "7.02%", null, this.div_search);
            obj.set_taborder("2");
            obj.set_cssclass("btn_WF_schArea");
            obj.getSetter("domainId").set("nexa.search");
            this.div_search.addChild(obj.name, obj);
            obj = new Static("st_searchCondition", "absolute", "20", "-8", "64", "41", null, null, this.div_search);
            obj.set_taborder("3");
            obj.set_text("검색조건");
            obj.set_cssclass("sta_WF_schTitle");
            obj.getSetter("domainId").set("nexa.s_condition");
            this.div_search.addChild(obj.name, obj);
            obj = new Combo("cmb_searchCondition", "absolute", "86", "2", "140", "20", null, null, this.div_search);
            this.div_search.addChild(obj.name, obj);
            obj.set_taborder("0");
            obj.set_codecolumn("codeInfo");
            obj.set_datacolumn("nameInfo");
            obj.getSetter("domainId").set("nexa.name;nexa.code");
            obj.set_innerdataset("@ds_combo");
            obj.set_value("0");
            obj.set_text("선택");
            obj.set_index("0");
            obj = new Edit("edt_searchKeyword", "absolute", "228", "2", "260", "20", null, null, this.div_search);
            obj.set_taborder("1");
            this.div_search.addChild(obj.name, obj);

            obj = new Div("div_grid_top", "absolute", "-116", "52", null, "23", "800", null, this);
            obj.set_taborder("1");
            obj.set_scrollbars("none");
            this.addChild(obj.name, obj);
            obj = new Static("sta_title", "absolute", "26", "-3", "132", "16", null, null, this.div_grid_top);
            obj.set_taborder("20");
            obj.set_text("Records Found");
            obj.set_cssclass("sta_WF_GridFound2");
            this.div_grid_top.addChild(obj.name, obj);
            obj = new Static("sta_total_cnt", "absolute", "0", "3", "22", "16", null, null, this.div_grid_top);
            obj.set_taborder("21");
            obj.set_text("0");
            obj.set_cssclass("sta_WF_GridFound");
            obj.style.set_align("right middle");
            this.div_grid_top.addChild(obj.name, obj);

            obj = new Static("Static27", "absolute", "0", "46", null, "15", "0", null, this);
            obj.set_taborder("2");
            obj.set_text("h15");
            obj.set_cssclass("Guide_color");
            obj.set_visible("false");
            this.addChild(obj.name, obj);

            obj = new Div("div_grid_bottom", "absolute", "0", "196", null, "20", "0", null, this);
            obj.set_taborder("4");
            obj.set_scrollbars("none");
            this.addChild(obj.name, obj);

            obj = new Div("div_grid_bottom00", "absolute", "0", "210", null, "20", "0", null, this);
            obj.set_taborder("8");
            obj.set_scrollbars("none");
            this.addChild(obj.name, obj);
            obj = new Static("sta_bg", "absolute", "0%", "0", null, null, "22.75%", "0", this.div_grid_bottom00);
            obj.set_taborder("33");
            obj.set_cssclass("sta_WF_GridDis");
            this.div_grid_bottom00.addChild(obj.name, obj);
            obj = new Static("sta_grid_cnt", "absolute", null, "0", "91", "20", "0", null, this.div_grid_bottom00);
            obj.set_taborder("34");
            obj.set_text("Rows : 0");
            this.div_grid_bottom00.addChild(obj.name, obj);
            obj = new Static("sta_msg", "absolute", "0", "0", null, "20", "131", null, this.div_grid_bottom00);
            obj.set_taborder("35");
            obj.set_text("There is no data.");
            obj.style.set_color("#444444ff");
            this.div_grid_bottom00.addChild(obj.name, obj);

            obj = new Button("btn_delRow", "absolute", null, "37", "55", "21", "120", null, this);
            obj.set_taborder("13");
            obj.set_text("행삭제");
            obj.set_cssclass("btn_CRUD");
            obj.getSetter("domainId").set("nexa.delete");
            this.addChild(obj.name, obj);

            obj = new Static("st_Title01", "absolute", "1.88%", "39", null, "22", "72.63%", null, this);
            obj.set_taborder("9");
            obj.set_text("목록");
            obj.set_wordwrap("english");
            obj.set_cssclass("sta_WF_title");
            obj.getSetter("domainId").set("nexa.code.list");
            this.addChild(obj.name, obj);

            obj = new Button("btn_cancelList", "absolute", null, "37", "55", "21", "63", null, this);
            obj.set_taborder("5");
            obj.set_text("취소");
            obj.set_cssclass("btn_CRUD");
            obj.getSetter("domainId").set("nexa.delete");
            this.addChild(obj.name, obj);

            obj = new Button("btn_saveList", "absolute", null, "37", "58", "21", "3", null, this);
            obj.set_taborder("6");
            obj.set_text("저장");
            obj.set_cssclass("btn_CRUD");
            obj.getSetter("domainId").set("nexa.add");
            this.addChild(obj.name, obj);

            obj = new Div("div_grid_top00", "absolute", "0", "231", null, "23", "0", null, this);
            obj.set_taborder("10");
            obj.set_scrollbars("none");
            this.addChild(obj.name, obj);
            obj = new Button("btn_saveInfo", "absolute", null, "0", "50", "23", "3", null, this.div_grid_top00);
            obj.set_taborder("3");
            obj.set_text("저장");
            obj.set_cssclass("btn_WF_CRUD");
            obj.getSetter("domainId").set("nexa.save");
            this.div_grid_top00.addChild(obj.name, obj);
            obj = new Button("btn_initInfo", "absolute", null, "0", "50", "23", "159", null, this.div_grid_top00);
            obj.set_taborder("0");
            obj.set_text("초기화");
            obj.set_cssclass("btn_WF_CRUD");
            obj.getSetter("domainId").set("nexa.reset");
            this.div_grid_top00.addChild(obj.name, obj);
            obj = new Button("btn_cancelInfo", "absolute", null, "0", "50", "23", "107", null, this.div_grid_top00);
            obj.set_taborder("1");
            obj.set_text("취소");
            obj.set_cssclass("btn_WF_CRUD");
            obj.getSetter("domainId").set("nexa.add");
            this.div_grid_top00.addChild(obj.name, obj);
            obj = new Button("btn_delInfo", "absolute", null, "0", "50", "23", "55", null, this.div_grid_top00);
            obj.set_taborder("4");
            obj.set_cssclass("btn_WF_CRUD");
            obj.getSetter("domainId").set("nexa.delete");
            obj.set_text("삭제");
            this.div_grid_top00.addChild(obj.name, obj);

            obj = new Div("divInput", "absolute", "0", "255", null, null, "0", "3", this);
            obj.set_taborder("11");
            obj.style.set_border("1 solid #808080ff");
            this.addChild(obj.name, obj);
            obj = new Static("stc_id", "absolute", "2.13%", "7", null, "26", "87.34%", null, this.divInput);
            obj.set_taborder("1");
            obj.set_text("ID");
            obj.style.set_background("lavender left middle");
            obj.style.set_padding("1px 1px 1px 10");
            obj.style.set_font("9 Dotum");
            obj.getSetter("class").set("sub_title");
            this.divInput.addChild(obj.name, obj);
            obj = new Static("Static01", "absolute", "32.58%", "36", null, "26", "56.89%", null, this.divInput);
            obj.set_taborder("2");
            obj.set_text("EngName");
            obj.style.set_background("lavender");
            obj.style.set_padding("0 0 0 10");
            obj.style.set_font("9 Dotum");
            this.divInput.addChild(obj.name, obj);
            obj = new Static("Static07", "absolute", "2.13%", "94", null, "26", "87.34%", null, this.divInput);
            obj.set_taborder("3");
            obj.set_text("company");
            obj.style.set_background("lavender");
            obj.style.set_padding("0 0 0 10");
            obj.style.set_font("9 Dotum");
            this.divInput.addChild(obj.name, obj);
            obj = new Edit("edt_id", "absolute", "13.28%", "7", null, "26", "68.17%", null, this.divInput);
            obj.set_taborder("0");
            this.divInput.addChild(obj.name, obj);
            obj = new Edit("edtEngName", "absolute", "44.49%", "36", null, "26", "36.97%", null, this.divInput);
            obj.set_taborder("11");
            this.divInput.addChild(obj.name, obj);
            obj = new Static("stc_name", "absolute", "2.13%", "36", null, "26", "87.34%", null, this.divInput);
            obj.set_taborder("4");
            obj.set_text("FullName");
            obj.style.set_background("lavender left middle");
            obj.style.set_padding("1px 1px 1px 10");
            obj.style.set_font("9 Dotum");
            obj.getSetter("class").set("sub_title");
            this.divInput.addChild(obj.name, obj);
            obj = new Edit("edt_fullName", "absolute", "13.28%", "36", null, "26", "68.17%", null, this.divInput);
            obj.set_taborder("10");
            this.divInput.addChild(obj.name, obj);
            obj = new Static("stc_password", "absolute", "32.46%", "7", null, "26", "57.02%", null, this.divInput);
            obj.set_taborder("5");
            obj.set_text("PASSWORD");
            obj.style.set_background("lavender left middle");
            obj.style.set_padding("1px 1px 1px 10");
            obj.style.set_font("9 Dotum");
            obj.getSetter("class").set("sub_title");
            this.divInput.addChild(obj.name, obj);
            obj = new Edit("edt_password", "absolute", "44.49%", "7", null, "26", "36.97%", null, this.divInput);
            obj.set_taborder("8");
            obj.set_password("true");
            this.divInput.addChild(obj.name, obj);
            obj = new Edit("edt_phone", "absolute", "13.28%", "94", null, "26", "68.17%", null, this.divInput);
            obj.set_taborder("13");
            this.divInput.addChild(obj.name, obj);
            obj = new Static("Static00", "absolute", "32.46%", "94", null, "26", "57.02%", null, this.divInput);
            obj.set_taborder("6");
            obj.set_text("CellPhone");
            obj.style.set_background("lavender");
            obj.style.set_padding("0 0 0 10");
            obj.style.set_font("9 Dotum");
            this.divInput.addChild(obj.name, obj);
            obj = new Edit("edt_cellPhone", "absolute", "44.49%", "94", null, "26", "36.97%", null, this.divInput);
            obj.set_taborder("14");
            this.divInput.addChild(obj.name, obj);
            obj = new Static("Static02", "absolute", "2.13%", "65", null, "26", "87.34%", null, this.divInput);
            obj.set_taborder("7");
            obj.set_text("Email");
            obj.style.set_background("lavender");
            obj.style.set_padding("0 0 0 10");
            obj.style.set_font("9 Dotum");
            this.divInput.addChild(obj.name, obj);
            obj = new Edit("edt_email", "absolute", "13.28%", "65", null, "26", "68.17%", null, this.divInput);
            obj.set_taborder("12");
            this.divInput.addChild(obj.name, obj);
            obj = new Static("Static03", "absolute", "2.13%", "123", null, "26", "87.34%", null, this.divInput);
            obj.set_taborder("9");
            obj.set_text("ZipCode");
            obj.style.set_background("lavender");
            obj.style.set_padding("0 0 0 10");
            obj.style.set_font("9 Dotum");
            this.divInput.addChild(obj.name, obj);
            obj = new Edit("edt_zipCode", "absolute", "13.28%", "123", null, "26", "68.17%", null, this.divInput);
            obj.set_taborder("15");
            this.divInput.addChild(obj.name, obj);
            obj = new Static("Static04", "absolute", "32.46%", "65", null, "26", "57.02%", null, this.divInput);
            obj.set_taborder("16");
            obj.set_text("birthDay");
            obj.style.set_background("lavender");
            obj.style.set_padding("0 0 0 10");
            obj.style.set_font("9 Dotum");
            this.divInput.addChild(obj.name, obj);
            obj = new Calendar("Calendar00", "absolute", "44.49%", "68", null, "20", "42.73%", null, this.divInput);
            this.divInput.addChild(obj.name, obj);
            obj.set_taborder("18");
            obj.set_dateformat("yyyy-MM-dd");
            obj = new Static("Static05", "absolute", "32.46%", "123", null, "26", "57.02%", null, this.divInput);
            obj.set_taborder("19");
            obj.set_text("officerYn");
            obj.style.set_background("lavender");
            obj.style.set_padding("0 0 0 10");
            obj.style.set_font("9 Dotum");
            this.divInput.addChild(obj.name, obj);
            obj = new Radio("Radio00", "absolute", "43.98%", "121", null, "29", "37.22%", null, this.divInput);
            this.divInput.addChild(obj.name, obj);
            obj.set_taborder("20");
            obj.set_innerdataset("@ds_radio");
            obj.set_codecolumn("codeInfo");
            obj.set_datacolumn("nameInfo");
            obj.set_direction("vertical");
            obj = new Static("Static06", "absolute", "63.91%", "36", null, "26", "25.56%", null, this.divInput);
            obj.set_taborder("21");
            obj.set_text("EngName");
            obj.style.set_background("lavender");
            obj.style.set_padding("0 0 0 10");
            obj.style.set_font("9 Dotum");
            this.divInput.addChild(obj.name, obj);
            obj = new Static("stc_password00", "absolute", "63.78%", "7", null, "26", "25.69%", null, this.divInput);
            obj.set_taborder("22");
            obj.set_text("PASSWORD");
            obj.style.set_background("lavender left middle");
            obj.style.set_padding("1px 1px 1px 10");
            obj.style.set_font("9 Dotum");
            obj.getSetter("class").set("sub_title");
            this.divInput.addChild(obj.name, obj);
            obj = new Static("Static08", "absolute", "63.78%", "94", null, "26", "25.69%", null, this.divInput);
            obj.set_taborder("23");
            obj.set_text("CellPhone");
            obj.style.set_background("lavender");
            obj.style.set_padding("0 0 0 10");
            obj.style.set_font("9 Dotum");
            this.divInput.addChild(obj.name, obj);
            obj = new Static("Static09", "absolute", "63.78%", "65", null, "26", "25.69%", null, this.divInput);
            obj.set_taborder("24");
            obj.set_text("birthDay");
            obj.style.set_background("lavender");
            obj.style.set_padding("0 0 0 10");
            obj.style.set_font("9 Dotum");
            this.divInput.addChild(obj.name, obj);
            obj = new Static("Static10", "absolute", "63.78%", "123", null, "26", "25.69%", null, this.divInput);
            obj.set_taborder("25");
            obj.set_text("officerYn");
            obj.style.set_background("lavender");
            obj.style.set_padding("0 0 0 10");
            obj.style.set_font("9 Dotum");
            this.divInput.addChild(obj.name, obj);

            obj = new Static("stc_detail", "absolute", "2.13%", "236", null, "20", "77%", null, this);
            obj.set_taborder("12");
            obj.set_text("상세정보");
            obj.set_cssclass("sta_WF_title");
            this.addChild(obj.name, obj);

            obj = new Button("btn_addRow", "absolute", null, "37", "55", "21", "177", null, this);
            obj.set_taborder("3");
            obj.set_text("행추가");
            obj.set_cssclass("btn_CRUD");
            obj.getSetter("domainId").set("nexa.delete");
            this.addChild(obj.name, obj);


            
            // Layout Functions
            //-- Default Layout
            obj = new Layout("default", "", 0, 27, this.div_search,
            	//-- Layout function
            	function(p) {
            		p.set_taborder("0");
            		p.set_text("Div00");
            		p.set_scrollbars("none");
            		p.set_cssclass("div_WF_searchBg");

            	}
            );
            this.div_search.addLayout(obj.name, obj);

            //-- Default Layout
            obj = new Layout("default", "", 0, 23, this.div_grid_top,
            	//-- Layout function
            	function(p) {
            		p.set_taborder("1");
            		p.set_scrollbars("none");

            	}
            );
            this.div_grid_top.addLayout(obj.name, obj);

            //-- Default Layout
            obj = new Layout("default", "", 0, 20, this.div_grid_bottom,
            	//-- Layout function
            	function(p) {
            		p.set_taborder("4");
            		p.set_scrollbars("none");

            	}
            );
            this.div_grid_bottom.addLayout(obj.name, obj);

            //-- Default Layout
            obj = new Layout("default", "", 0, 20, this.div_grid_bottom00,
            	//-- Layout function
            	function(p) {
            		p.set_taborder("8");
            		p.set_scrollbars("none");

            	}
            );
            this.div_grid_bottom00.addLayout(obj.name, obj);

            //-- Default Layout
            obj = new Layout("default", "", 0, 23, this.div_grid_top00,
            	//-- Layout function
            	function(p) {
            		p.set_taborder("10");
            		p.set_scrollbars("none");

            	}
            );
            this.div_grid_top00.addLayout(obj.name, obj);

            //-- Default Layout
            obj = new Layout("default", "", 0, 0, this.divInput,
            	//-- Layout function
            	function(p) {
            		p.set_taborder("11");
            		p.style.set_border("1 solid #808080ff");

            	}
            );
            this.divInput.addLayout(obj.name, obj);

            //-- Default Layout
            obj = new Layout("default", "", 800, 422, this,
            	//-- Layout function
            	function(p) {
            		p.set_classname("CodeMgmt");
            		p.getSetter("inheritanceid").set("");
            		p.set_titletext("공통코드관리");

            	}
            );
            this.addLayout(obj.name, obj);


            
            // BindItem Information
            obj = new BindItem("item17","div_search.cmb_searchCondition","value","ds_Search","SEARCH_CONDITION");
            this.addChild(obj.name, obj);
            obj.bind();
            obj = new BindItem("item18","div_search.txt_config_title","value","ds_Search","SEARCH_KEYWORD");
            this.addChild(obj.name, obj);
            obj.bind();
            obj = new BindItem("item0","div_search00.cmb_searchCondition","value","ds_Search","SEARCH_CONDITION");
            this.addChild(obj.name, obj);
            obj.bind();
            obj = new BindItem("item1","div_search00.edt_searchKeyword","value","ds_Search","SEARCH_KEYWORD");
            this.addChild(obj.name, obj);
            obj.bind();
            obj = new BindItem("item2","divInput.edt_id","value","ds_dataInfo","userId");
            this.addChild(obj.name, obj);
            obj.bind();
            obj = new BindItem("item3","divInput.edtEngName","value","ds_dataInfo","enName");
            this.addChild(obj.name, obj);
            obj.bind();
            obj = new BindItem("item4","divInput.edt_fullName","value","ds_dataInfo","userName");
            this.addChild(obj.name, obj);
            obj.bind();
            obj = new BindItem("item5","divInput.edt_password","value","ds_dataInfo","password");
            this.addChild(obj.name, obj);
            obj.bind();
            obj = new BindItem("item6","divInput.edt_phone","value","ds_dataInfo","company");
            this.addChild(obj.name, obj);
            obj.bind();
            obj = new BindItem("item7","divInput.edt_cellPhone","value","ds_dataInfo","cellPhone");
            this.addChild(obj.name, obj);
            obj.bind();
            obj = new BindItem("item8","divInput.edt_email","value","ds_dataInfo","email");
            this.addChild(obj.name, obj);
            obj.bind();
            obj = new BindItem("item9","divInput.edt_zipCode","value","ds_dataInfo","compZipCode");
            this.addChild(obj.name, obj);
            obj.bind();
            obj = new BindItem("item10","grd_list","binddataset","ds_listInfo","");
            this.addChild(obj.name, obj);
            obj.bind();
            obj = new BindItem("item11","divInput.Calendar00","value","ds_dataInfo","birthDay");
            this.addChild(obj.name, obj);
            obj.bind();
            obj = new BindItem("item12","divInput.Radio00","value","ds_dataInfo","officerYn");
            this.addChild(obj.name, obj);
            obj.bind();

            
            // Remove Reference
            obj = null;
        };
        

        
        // User Script
        this.addIncludeScript("PilotSample.xfdl", "lib::comLib.xjs");
        this.registerScript("PilotSample.xfdl", function() {
        /***********************************************************************
         * 01. 업무구분 : Master-Detail
         * 02. 화면명   : PilotSample.xfdl
         * 03. 화면설명 : 
         * 04. 작성일   :
         * 05. 작성자   : 
         * 06. 수정이력 :
         ***********************************************************************
         *     수정일     작성자   내용
         ***********************************************************************
         *
         ***********************************************************************
         */

        /***********************************************************************
         * Script Include 
         ************************************************************************/
        //include "lib::comLib.xjs";

        /***********************************************************************
         * 화면 변수 선언부
         ************************************************************************/
         
        /***********************************************************************
         * Form Function
         ************************************************************************/

         // Form Load 시 공통 기능 처리
        this.form_onload = function (obj,e)
        {
        	//Ex.core.init(obj); 	
        }

        //사용자 정의 폼 로드 함수(form_init 고정)
        this.form_init = function(obj)
        {
            //this.fn_search();
        }

        /***********************************************************************************
        * Transaction Function
        ***********************************************************************************/

        //목록조회 Search
        this.fn_search = function()
        {

        	var sSvcID        	= "search";                    
            var sController   	= "searchUserVOList.do";
            
        	var sInDatasets   	= "ds_search=ds_search";
        	var sOutDatasets  	= "ds_listInfo=output1";
        	
        	var sArgs = "";	

        	this.ds_search.clearData();
            var rowIdx = this.ds_search.addRow();
        	// 조회조건(Condition)
        	this.ds_search.setColumn(rowIdx, "searchKeyword", this.div_search.edt_searchKeyword.value);
        	this.ds_search.setColumn(rowIdx, "searchCondition", this.div_search.cmb_searchCondition.value);
        	
        	Ex.core.tran(this,sSvcID, sController, sInDatasets, sOutDatasets, sArgs); 
        }

        /***********************************************************************************
        * CallBack Event (strSvcId - Sevice ID, nErrorCode - ErrorCode, strErrorMsg - Error Message)
        ***********************************************************************************/
        /* callBack함수 */
        this.fn_callBack = function (strSvcId,nErrorCode,strErrorMsg)
        { 
        	if (nErrorCode < 0) 
        	{
        		return Ex.core.comMsg("alert",strErrorMsg);		
        	}
        	switch (strSvcId)
        	{
        		case "search" :
        			this.fn_search_post();
        		 	break;
        		 	
        		case "select" : 
        			//this.alert("select user data complete!");
        			break;

        		case "save" :
        			//this.alert(ds_result.getColumn(0, "resCnt"));
        			//alert("aa");
        			this.fn_search_post();
        		 	break;

        // 		 case "modifyCodeGroup" :
        // 		    if (nErrorCode == 0) {
        // 				fn_save("modifyCodeList"); 
        // 		    }
        // 		    this.fn_search();
        // 			break;
        // 
        // 		 case "modifyCodeList" :
        // 		    this.fn_search();
        // 			break;
        	}
        }

        /***********************************************************************************
        * Component Event
        ***********************************************************************************/

        //목록조회 Search
        this.div_search_btn_search_onclick = function(obj,e)
        {
        	this.fn_search();
        }

        // 검색시 Enter 키 이벤트 처리
        this.div_search_edt_searchKeyword_onkeyup = function(obj,e)
        {
        	if ( e.keycode == 13)
        	{
        		this.fn_search();
        	}
        }

        /***********************************************************************************
        * User Function
        ***********************************************************************************/
        //페이징 없는 경우

        this.fn_search_post = function()
        {
        	var nTotalCnt01 = this.ds_listInfo.rowcount;

        	this.div_grid_bottom00.sta_msg.set_text("Select has been complted successfully.");	

        	this.div_grid_bottom00.sta_grid_cnt.set_text("Rows : "+nTotalCnt01);
        }

        
        // grid double click event handler
        this.grd_list_oncelldblclick = function(obj,e){

        	var sSvcID        	= "select";                    
            var sController   	= "selectUserInfo.do";
            
        	var sInDatasets   	= "ds_search=ds_search";
        	var sOutDatasets  	= "ds_dataInfo=output1";
        	
        	var sArgs = "";	

        	this.ds_search.clearData();
        	this.ds_dataInfo.clearData();
        	
        	var rowIdx = this.ds_listInfo.rowposition;
        	var selectedUserId = this.ds_listInfo.getColumn(rowIdx, "userId");
        	//this.alert(selectedUserId);
            var addRowIdx = this.ds_search.addRow();
        	this.ds_search.setColumn(addRowIdx, "searchKeyword", selectedUserId);
        	this.ds_search.setColumn(addRowIdx, "searchCondition", "ID");
        	
        	Ex.core.tran(this,sSvcID, sController, sInDatasets, sOutDatasets, sArgs); 
        }

        // 초기화
        this.fn_reset = function(obj,e)
        {
        	this.ds_dataInfo.clearData();
        	var addedIdx = this.ds_dataInfo.addRow();
        }

        // 단건저장
        this.fn_save = function(obj,e)
        {
        	if (this.ds_dataInfo.getRowCount() < 1) {
        		this.alert("저장할 데이터가 없습니다.");
        		return;
        	}
        	
        	var sSvcID        	= "save";                    
            var sController   	= "saveUserInfo.do";
            
            var sInDatasets   	= "ds_dataInfo=ds_dataInfo:U";
        	var sOutDatasets  	= "ds_result=ds_result";
        	
        	var sArgs = "";	
        	
        	if ( this.confirm("저장하시겠습니까?", "저장") ) {
        		Ex.core.tran(this,sSvcID, sController, sInDatasets, sOutDatasets, sArgs); 
        	} else {
        		return;
        	}
        }

        // 그리드 행추가
        this.btn_addRow_onclick = function(obj,e)
        {
        	this.alert(this.ds_listInfo.getColCount());
        	this.ds_listInfo.addRow();
        	this.alert(this.ds_listInfo.getColCount());
        	return;
        }

        // 그리드 행삭제
        this.btn_delRow_onclick = function(obj,e)
        {
        	var nRow = this.ds_listInfo.rowposition;
        	
        	this.ds_listInfo.deleteRow(nRow);
        	
        	trace(this.ds_listInfo.getDeletedRowCount());
        	
        	trace(this.ds_listInfo.getDeletedRowset());
        	
        	
        	
        	
        }

        this.btn_cancelList_onclick = function(obj,e)
        {
        	this.ds_listInfo.reset();
        }

        
        this.fn_delete = function(obj,e)
        {
        	trace("전 : " + this.ds_dataInfo.getDeletedRowCount());
        	this.ds_dataInfo.deleteRow(0);
        	trace("후 : " + this.ds_dataInfo.getDeletedRowCount());
        }
        
        });


        
        // Regist UI Components Event
        this.on_initEvent = function()
        {
            this.ds_listInfo.addEventHandler("canrowposchange", this.ds_codeGroupList_canrowposchange, this);
            this.ds_listInfo.addEventHandler("onrowposchanged", this.ds_codeGroupList_onrowposchanged, this);
            this.ds_listInfo.addEventHandler("cancolumnchange", this.ds_codeGroupList_cancolumnchange, this);
            this.addEventHandler("onload", this.form_onload, this);
            this.addEventHandler("onbeforeclose", this.form_onbeforeclose, this);
            this.grd_list.addEventHandler("oncelldblclick", this.grd_list_oncelldblclick, this);
            this.grd_list.addEventHandler("onheadclick", this.grd_list_onheadclick, this);
            this.div_search.btn_search.addEventHandler("onclick", this.fn_search, this);
            this.div_search.edt_searchKeyword.addEventHandler("onkeyup", this.div_search_edt_searchKeyword_onkeyup, this);
            this.btn_delRow.addEventHandler("onclick", this.btn_delRow_onclick, this);
            this.st_Title01.addEventHandler("onclick", this.st_Title01_onclick, this);
            this.btn_cancelList.addEventHandler("onclick", this.btn_cancelList_onclick, this);
            this.btn_saveList.addEventHandler("onclick", this.div_grid_top_btn_add_onclick, this);
            this.div_grid_top00.btn_saveInfo.addEventHandler("onclick", this.fn_save, this);
            this.div_grid_top00.btn_initInfo.addEventHandler("onclick", this.fn_reset, this);
            this.div_grid_top00.btn_cancelInfo.addEventHandler("onclick", this.fn_add, this);
            this.div_grid_top00.btn_delInfo.addEventHandler("onclick", this.fn_delete, this);
            this.btn_addRow.addEventHandler("onclick", this.btn_addRow_onclick, this);

        };

        this.loadIncludeScript("PilotSample.xfdl");

       
    };
}
)();
