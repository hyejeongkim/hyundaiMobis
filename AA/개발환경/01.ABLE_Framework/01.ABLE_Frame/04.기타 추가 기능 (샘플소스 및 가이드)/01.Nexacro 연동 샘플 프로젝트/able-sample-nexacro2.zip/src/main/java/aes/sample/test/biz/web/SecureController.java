package aes.sample.test.biz.web;

import javax.annotation.Resource;

import able.com.ui.adaptor.annotation.ParamDataSet;
import able.com.ui.adaptor.annotation.ParamVariable;
import able.com.web.HController;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import able.com.ui.adaptor.nexacro.data.NexacroResult;
import com.nexacro.xapi.data.DataSet;
import com.nexacro.xapi.data.Debugger;
import com.nexacro.xapi.data.PlatformData;

import aes.sample.test.biz.service.SampleService;

/**
 * <pre>
 * Test를 위한 Controller Sample Class
 * </pre>
 * 
 * @ClassName   : SecureController.java
 * @Description : Secure Controller Class
 * @author djkim
 * @since 2012. 1. 31.
 * @version 1.0
 * @see
 * @Modification Information
 * 
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2012. 1. 31.     djkim     최초 생성
 * </pre>
 */
@Controller
public class SecureController extends HController {

    // @Autowired(required = false) // Type 정의
    @Resource(name = "sampleService")
    // Name 정의
    private SampleService sampleService;
    
    @RequestMapping(value = "/secureSelectVO.do")
     public NexacroResult secureData(
                              @ParamVariable(name="id")  String paramValue
                            , @ParamDataSet(name="dsInput") DataSet dsUnit
                            , PlatformData platformData){
        
        /*if (log.isDebugEnabled()) {
            System.out.println("SecureController.secureData()");
            log.debug("SecureController.secureData(). data="+new Debugger().detail(platformData));
        }*/
        
        System.out.println("id: " + paramValue);
        System.out.println("dsInput"+new Debugger().detail(dsUnit));

        NexacroResult result = new NexacroResult();
        return result;
    }
}
