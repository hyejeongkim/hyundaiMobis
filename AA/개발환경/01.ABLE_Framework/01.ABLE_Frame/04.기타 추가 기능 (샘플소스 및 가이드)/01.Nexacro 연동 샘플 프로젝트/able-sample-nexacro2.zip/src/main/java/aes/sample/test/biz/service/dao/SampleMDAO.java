package aes.sample.test.biz.service.dao;

import java.util.List;

import org.springframework.stereotype.Repository;

import able.com.mybatis.Mapper;
import able.com.ui.adaptor.nexacro.dao.mybatis.NexacroHsqlAbstractDAO;

import aes.sample.test.biz.vo.SampleVO;

/**
 * <pre>
 * Test를 위한 DAO Sample Class
 * </pre>
 * 
 * @ClassName   : java
 * @Description : Sample DAO Class
 * @author djkim
 * @since 2012. 1. 31.
 * @version 1.0
 * @see
 * @Modification Information
 * 
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2012. 1. 31.     djkim     최초 생성
 * </pre>
 */
@Mapper("sampleMDAO")
public interface SampleMDAO {

    public List<SampleVO> selectSampleVoList(SampleVO searchVO) ;

    public void insertSampleVO(SampleVO sample) ;
    
    public void updateSampleVO(SampleVO sample) ;
    
    public void deleteSampleVO(SampleVO sample) ;

}
