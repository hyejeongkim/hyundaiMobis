package aes.sample.test.biz.service;

import java.util.List;

import aes.sample.test.biz.vo.SampleVO;


/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName   : SampleService.java
 * @Description : 클래스 설명을 기술합니다.
 * @author Autoever
 * @since 2017. 10. 31.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2017. 10. 31.     Autoever     	최초 생성
 * </pre>
 */
public interface SampleService {

    List<SampleVO> selectSampleVOList(SampleVO searchVO);

    void modifyMultiSampleVO(List<SampleVO> modifyList);

}
