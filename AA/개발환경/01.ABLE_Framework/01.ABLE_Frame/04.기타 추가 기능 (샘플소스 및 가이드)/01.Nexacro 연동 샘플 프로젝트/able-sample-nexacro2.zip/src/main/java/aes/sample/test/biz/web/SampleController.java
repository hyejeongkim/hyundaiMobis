package aes.sample.test.biz.web;

import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import able.com.ui.adaptor.annotation.ParamDataSet;
import able.com.ui.adaptor.annotation.ParamVariable;
import able.com.web.HController;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import able.com.ui.adaptor.nexacro.data.NexacroFirstRowHandler;
import able.com.ui.adaptor.nexacro.data.NexacroResult;
import com.nexacro.xapi.data.DataSet;
import com.nexacro.xapi.data.DataSetList;
import com.nexacro.xapi.data.Debugger;
import com.nexacro.xapi.data.PlatformData;
import com.nexacro.xapi.data.Variable;
import com.nexacro.xapi.data.VariableList;
import com.nexacro.xapi.tx.HttpPlatformRequest;
import com.nexacro.xapi.tx.HttpPlatformResponse;

import aes.sample.test.biz.service.SampleService;
import aes.sample.test.biz.vo.SampleVO;
import aes.sample.test.biz.vo.UnitVO;


@Controller
public class SampleController extends HController {

    // @Autowired(required = false) // Type 정의
    @Resource(name = "sampleService")
    // Name 정의
    private SampleService sampleService;
    
    @RequestMapping(value = "/sampleSelectVO.do")
    public NexacroResult selectVo(
                            @ParamDataSet(name="ds_search") List<SampleVO> searchVOList
                            , @ParamDataSet(name="__DS_PARAM_INFO__") List<Map> defaultList
                            , PlatformData platformData){
        
/*        if (log.isDebugEnabled()) {
            System.out.println("SampleController.selectVo()");
            log.debug("SampleController.selectVo(). data="+new Debugger().detail(platformData));
        }*/
        
        SampleVO searchVo = null;
        if(searchVOList != null && searchVOList.size() > 0) {
            searchVo = searchVOList.get(0);
        }
        
        List<SampleVO> sampleList = sampleService.selectSampleVOList(searchVo);
        
        NexacroResult result = new NexacroResult();
        result.addDataSet("output1", sampleList);
        
        return result;
    }
    
    @RequestMapping(value = "/sampleModifyVO.do")
    public NexacroResult modifyVO(
                            @ParamDataSet(name="input1") List<SampleVO> modifyList
                            , PlatformData platformData){
        
/*        if (log.isDebugEnabled()) {
            System.out.println("SampleController.modifyVO");
            log.debug("SampleController.selectVo(). data="+new Debugger().detail(platformData));
        }*/
        
        sampleService.modifyMultiSampleVO(modifyList);
        
        NexacroResult result = new NexacroResult();
        
        return result;
    }
    
    @RequestMapping(value = "/test.do")
    public NexacroResult test(
            @ParamDataSet(name="dsUnit") List<UnitVO> unitList
            , @ParamDataSet(name="dsUnit") List<Map> unitMapList
            , @ParamDataSet(name="dsUnit") DataSet dsUnit
            
            , @ParamVariable(name="intValue") int iVar1
            , @ParamVariable(name="intValue") Variable iVar2
            , @ParamVariable(name="stringValue") String sVar1
            , @ParamVariable(name="stringValue") Variable sVar2
            
            , DataSetList dsList
            , VariableList varList
            , PlatformData platformData
            , HttpPlatformRequest platformRequest
            , HttpPlatformResponse platformResponse
            , NexacroFirstRowHandler firstRowHandler
            ){
/*        
        if (log.isDebugEnabled()) {
            log.debug("debug_message : nexacro supported parameter types..");
        }*/
        
        // control nexacro result...
        NexacroResult result = new NexacroResult();
        result.addDataSet("dsUnitList", unitList);
        result.addVariable("responseInt", iVar1);
        result.addVariable("responseString", sVar1);
        
        
        return result;
    }
    
}
