﻿/************************************************************************************************************
---- 기능 확장  XJS (Dataset)

1. extIsUpdate            -- Dataset이 Insert/Modify/Delete 되었는지 체크
2. extFindRowArray        -- Dataset에서 expr에 맞는 모든 Row Index를 찾아 배열로 리턴한다.

3. extKeystring           -- sort와 keystring 를 동시에 사용 하때 set_keystring를 사용  하지 않고 extKeystring 를 사용 한다
                             주의 : keystring를 사용 하여 Group 할경우 해당 Group로 Sort 시에만 사용 해야 한다

4. extGetOrgRow           -- 그룹핑 되어 있을 경우 소계 로우를 제외한 로우 표시
5. extAddRow              -- 데이타셋의 row를 추가 하며 추가  한 데이타셋의컬럼중 String 타입 컬럼에 empty("") 값을 넣어 준다
5. extResetRow            -- 수정된 Row를 original 데이타로 원복한다.
6.gfn_clearSortMark       -- Sort Mark 제거
*************************************************************************************************************/
/**
* isNull(string)
* 작 성 자 : 
* 작 성 일 : 
* 개    요 : 입력값이 null인지 체크
* 김종현 수정 
* return값 : true, false
*/
this.utils = function (){

    return { 		
		gfn_isNullEmpty : function (sVal)
		{
			if (new String(sVal).valueOf() == "undefined" || new String(sVal).valueOf() == "null" || sVal == undefined || sVal == null) {
				return true;
			}
			else 
			{
				var stringValue = new String(sVal);
				if (stringValue == null || stringValue.trim() == "") {
					return true;
				}
				
				if (stringValue.length == 0){
					return true;
				}
			}
			return false;		
		},
		/**
		* containsChars(string, strChars)
		* 개    요 : 입력값에 특정 문자(chars)가 있는지 체크
		*            특정 문자를 허용하지 않으려 할 때 사용
		*            ex) if (containsChars("test@aaa","!,*&^%$#@~;")) {
		*                     alert("이름 필드에는 특수 문자를 사용할 수 없습니다.");
		*                 }
		* return값 : true, false
		*/
		gfn_containsChars : function(sVal, a_chars) {
			if (this.gfn_isNullEmpty(sVal))
				return false;

			for (var intInx = 0; intInx < sVal.length; intInx++) {
				if (a_chars.indexOf(sVal.charAt(intInx)) != -1) {
					return true;
				}
			}		
			return false;
		},
		/**
		* containsCharsOnly(string, strChars)
		* 작 성 자 : 
		* 작 성 일 : 
		* 개    요 : 입력값이 특정 문자(strChars)만으로 되어있는지 체크
		*            특정 문자만 허용하려 할 때 사용
		*            ex) if (!gfn_containsCharsOnly(form.blood,"ABO")) {
		*                    alert("혈액형 필드에는 A,B,O 문자만 사용할 수 있습니다.");
		*                }
		* return값 : true, false
		*/
		gfn_containsCharsOnly : function(sVal, a_chars) {
			for (var intInx = 0; intInx < sVal.length; intInx++) {
				if (a_chars.indexOf(sVal.charAt(intInx)) == -1) {
					return false;
				}
			}
			return true;
		},
		/**
		* isAlphabet(string)
		* 개    요 : 입력값이 알파벳인지 체크
		*            아래 gfn_isAlphabet() 부터 gfn_isNumComma()까지의 메소드가
		*            자주 쓰이는 경우에는 var strChars 변수를
		*            global 변수로 선언하고 사용하도록 한다.
		*            ex) var uppercase = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
		*                var lowercase = "abcdefghijklmnopqrstuvwxyz";
		*                var number    = "0123456789";
		*                function gfn_isAlphaNum(str) {
		*                    var strChars = uppercase + lowercase + number;
		*                    return gfn_containsCharsOnly(obj,strChars);
		*                }
		* return값 : true, false
		*/
		gfn_isAlphabet : function(sVal) {
			var sChars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz";
			return this.gfn_containsCharsOnly(sVal, sChars);
		},
		/**
		* isUpperCase(obj)
		* 개    요 : 입력값이 알파벳 대문자인지 체크
		* return값 : true, false
		*/
		gfn_isUpperCase : function(sVal) {
			var sChars = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
			return this.gfn_containsCharsOnly(sVal,sChars);
		},
		/**
		* isLowerCase(obj)
		* 개    요 : 입력값이 알파벳 소문자인지 체크
		* return값 : true, false
		*/
		gfn_isLowerCase : function(sVal) {
			var sChars = "abcdefghijklmnopqrstuvwxyz";
			return this.gfn_containsCharsOnly(sVal,sChars);
		},
		/**
		* isNumber(obj)
		* 개    요 : 입력값에 숫자만 있는지 체크
		* return값 : true, false
		*/
		gfn_isNumber : function (sVal) {
			var sChars = "0123456789";
			return this.gfn_containsCharsOnly(sVal,sChars);
		},
		/**
		* isAlphaNum(obj)
		* 개    요 : 입력값이 알파벳,숫자로 되어있는지 체크
		* return값 : true, false
		*/
		gfn_isAlphaNum : function (sVal) {
			var sChars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
			return this.gfn_containsCharsOnly(sVal,sChars);
		},
		/**
		* isNumDash(obj)
		* 개    요 : 입력값이 숫자,대시(-)로 되어있는지 체크
		* return값 : true, false
		*/
		gfn_isNumDash : function (sVal) {
			var sChars = "-0123456789";
			return this.gfn_containsCharsOnly(sVal,sChars);
		},
		/**
		* isNumComma(str)
		* 개    요 : 입력값이 숫자,콤마(,)점(.)으로 되어있는지 체크
		* return값 : true, false
		*/
		gfn_isNumComma : function (sVal) {
			var sChars = ".,0123456789";
			return this.gfn_containsCharsOnly(sVal,sChars);
		},
		/**
		* isValidFormat(str,format)
		* 개    요 : 입력값이 사용자가 정의한 포맷 형식인지 체크
					 자세한 format 형식은 자바스크립트의 'regular expression'을 참조
		* return값 : true, false
		*/
		gfn_isValidFormat : function (sVal,format) {
			if (sVal.search(format) != -1) {
				return true; //올바른 포맷 형식
			}
			return false;
		},
		/**
		* isValidEmail(str)
		* 개    요 : 입력값이 이메일 형식인지 체크
		* return값 : true, false
		*/
		gfn_isValidEmail : function (sVal) {
		//    var format = /^(\S+)@(\S+)\.([A-Za-z]+)$/;
			var sFormat = /^((\w|[\-\.])+)@((\w|[\-\.])+)\.([A-Za-z]+)$/;
			return this.gfn_isValidFormat(sVal,sFormat);
		},
		/**
		* isValidPhone(str)
		* 개    요 : 입력값이 전화번호 형식(숫자-숫자-숫자)인지 체크
		* return값 : true, false
		*/
		gfn_isValidPhone : function (sVal) {
			var sFormat = /^(\d+)-(\d+)-(\d+)$/;
			return this.gfn_isValidFormat(sVal,sFormat);
		},
		/**
		* removeComma(str)
		* 개    요 : 입력값에서 콤마를 없앤 문자열 리턴
		* return값 : string
		*/
		gfn_removeComma : function (sVal) {
			return sVal.replace(/,/gi,"");
		},
		/**
		* getByteLength(str)
		* 개    요 : 입력값의 바이트 길이를 리턴
		* return값 : integer, integer
		*/
		gfn_getByteLength : function (sVal) {
			var nByteLength = 0;
			
			for (var nInx = 0; nInx < sVal.length; nInx++) 
			{
				var oneChar = escape(sVal.charAt(nInx));
				if ( oneChar.length == 1 ) {
					nByteLength ++;
				} else if (oneChar.indexOf("%u") != -1) {
					nByteLength += 2;
				} else if (oneChar.indexOf("%") != -1) {
					nByteLength += oneChar.length/3;
				} 
			}
			return nByteLength;
		},
		/**
		* getRawData(str)
		* 개    요 : 입력값에서 구분자인 '/', '.', '-',':', ' ' 등을 제거하여 리턴
		* return값 : string
		*/
		gfn_getRawData : function (sVal) {
			if (this.gfn_isNullEmpty(sVal))
				return "";

			sVal = sVal.replace(/\//g,"");
			sVal = sVal.replace(/-/g,"");
			sVal = sVal.replace(/\./g,"");
			sVal = sVal.replace(/\:/g,"");
			sVal = sVal.replace(/\ /g,"");
			return sVal;
		},
		/**
		* isYYYYMM(strDate)
		* 개    요 : 년월 6자리 날짜 valid Check
					 valid이면 YYYY-MM의 형식으로 리턴
					 invalid이면 ""로 리턴
		* return값 : string
		*/
		gfn_isYYYYMM : function (date) {
			date = this.gfn_getRawData(date);

			var sYear = "", sMonth = "";
			var nYear = 0, nMonth = 0;

			if(date.length != 6) {
				return false;
			} else {
				sYear = date.substring(0,4);
				sMonth = date.substring(4,6);
			}

			if(isNaN(sYear) || isNaN(sMonth))
				return false;

			nYear = parseInt(sYear,'10');
			nMonth = parseInt(sMonth,'10');

			if (nYear < 0001)
				nYear = 0;
			if (nMonth < 01 || nMonth > 12)
				nMonth = 0;

			if(nYear == 0 || nMonth == 0 )
				return false;

			return sYear+"-"+sMonth;
		},
		/**
		* isYYYYMMDD(a_date)
		* 개    요 : 년월일 8자리 날짜 valid Check
					 valid이면 YYYY-MM-DD의 형식으로 리턴
					 invalid이면 ""로 리턴
		* return값 : string
		*/
		gfn_isYYYYMMDD : function (date) {
			date = this.gfn_getRawData(date);
		
			var sYear = "", sMonth = "", sDay = "";
			var nYear = 0, nMonth = 0, nDay = 0;
		
			if(date.length != 8) {
				return false;
			} else {
				sYear = date.substring(0,4);
				sMonth = date.substring(4,6);
				if(parseFloat(sMonth) < 10)
					sMonth = "0" + parseFloat(nexacro.trim(sMonth));
		
				sDay = date.substring(6,8);
				if(parseFloat(sDay) < 10)
					sDay = "0" + parseFloat(nexacro.trim(sDay));
			}
		
			if(isNaN(sYear) || isNaN(sMonth) || isNaN(sDay))
				return false;
		
			nYear = parseInt(sYear,'10');
			nMonth = parseInt(sMonth,'10');
			nDay = parseInt(sDay,'10');
		
			if (nYear < 1)
				nYear = 0;
			if (nMonth < 1 || nMonth > 12)
				nMonth = 0;
			if (nDay < 1)
				nDay = 0;
		
			if ( nMonth == 1 || nMonth == 3 || nMonth == 5 || nMonth == 7 || nMonth == 8 ||
				 nMonth == 10 || nMonth == 12)  {
				if (nDay > 31)
					nDay = 0;
			} else if (nMonth == 4 || nMonth == 6 ||  nMonth == 9 || nMonth == 11) {
				if (nDay > 30)
					nDay = 0;
			} else if (nMonth == 2 )  {
				if (nYear % 4 != 0 || (nYear % 100 == 0 && nYear % 400 != 0)) {
					if (nDay > 28)
						nDay = 0;
				} else if (nDay > 29)
					nDay = 0;
			}
			if(nYear == 0 || nMonth == 0 || nDay == 0)
				return false;
		
			return sYear+"-"+sMonth+"-"+sDay;
		},
		/**
		* ltrim(sVal)
		* 개    요 : 문자열내의 왼쪽 공백을 제거
		* return값 : string
		*/
		gfn_ltrim : function( sVal ) {
			var nLen = sVal.length;
			var nIdx = 0;
			for(nIdx=0 ; nIdx<nLen; nIdx++ ) {
				if( sVal.charAt(nIdx)!=' ' && sVal.charAt(nIdx)!='\r' && sVal.charAt(nIdx)!='\n' && sVal.charAt(nIdx)!='\t')
					break;
			}

			return sVal.substring( nIdx,nLen );
		},
		/**
		* rtrim(a_sVal)
		* 개    요 : 문자열내의 오른쪽 공백을 제거
		* return값 : string
		*/
		gfn_rtrim : function ( sVal ) {
			var nLen = sVal.length;
			var nIdx = 0;
			for(nIdx = nLen-1 ; nIdx >= 0; nIdx-- ) {
				if( sVal.charAt(nIdx)!=' ' && sVal.charAt(nIdx)!='\r' && sVal.charAt(nIdx)!='\n' && sVal.charAt(nIdx)!='\t')
					break;
			}

			return sVal.substring( 0, nIdx + 1 );
		},
		/**
		* maskAmt(sVal)
		* 작 성 자 : 
		* 작 성 일 : 
		* 개    요 : 숫자를 금액으로 변환
		* return값 : string
		*/
		gfn_maskAmt : function (sVal) {
			var sRst = "";
			var nOrd = sVal.length;

			if((sVal.substring(0,1)) == "-") {
				sVal = sVal.substring(1,nOrd);
				nOrd -= 1; sRst = "-";
			}

			for(var i = 0; i < sVal.length; i++) {
				sRst += sVal.substring(i, i+1);

				if(nOrd != 1 && (nOrd-1) % 3 == 0)
					sRst += ",";
				nOrd -= 1;
			}

			return sRst;
		},
		/**
		* maskDate(sDate)
		* 개    요 : 날짜를 체크하고 YYYY-MM-DD로 convert
		* return값 : string
		*/
		gfn_maskDate : function (sDate, nLen) {
			var sRawDate = this.gfn_getRawData(sDate);
			var sRetStr = "";
			
			if (this.gfn_isNullEmpty(sRawDate))
				return "";
			
			var nLen = (nLen != undefined && nLen != null)?nLen:sRawDate.length;
			
			if (nLen >= 8) {
				sRetStr += sRawDate.substr(0, 4) + "-" + sRawDate.substr(4, 2) + "-" + sRawDate.substr(6, 2);
			}
			
			if (nLen >= 12) {
				sRetStr += " " + sRawDate.substr(8, 2) + ":" + sRawDate.substr(10, 2);
			}

			if (nLen >= 14) {
				sRetStr += ":" + sRawDate.substr(12, 2);
			}

			return sRetStr;
		},
		/**
		 * @class 날짜에 대한 형식 체크
		 * @param sFdate - 검사일자
		 * @return 유효성반환 (날짜형식이 아닐경우 FLASE)
		 */  
		gfn_isDate : function (sDate)
		{
			var sWrapper = new String(sDate);
			sWrapper = sWrapper.replace("/","").replace("/","");
			sWrapper = sWrapper.replace("-","").replace("-","");
			sWrapper = sWrapper.replace(".","").replace(".","");
			
			if (sWrapper.toString().length == 6) sWrapper + "01"; 
			
			if (sWrapper.toString().length !== 8) return false;
			
			var nMonth  = Math.floor(sWrapper.slice(4,6), 10);
			var nDate   = Math.floor(sWrapper.slice(6,8), 10);

			if (nMonth < 1 || nMonth > 12) return false;
			if (nDate < 1 || nDate > this.gfn_lastDateNum(sWrapper)) return false;

			return true;
		},
		/**
		 * @class 해당월의 마지막 날짜를 숫자로 구하기
		 * @param sDate : yyyyMMdd형태의 날짜 (예 : "20121122")
		 * @return - 성공 = 마지막 날짜 숫자값 (예 : 30)/ - 실패 = -1
		 */  
		gfn_lastDateNum : function (sDate)
		{
			var nMonth,nLastDate;

			if (this.gfn_isNullEmpty(sDate)){
				return -1;
			}

			nMonth = parseInt(sDate.substr(4, 2), 10);
			
			if (nMonth == 1 || nMonth == 3 || nMonth == 5 || nMonth == 7 || nMonth == 8 || nMonth == 10 || nMonth == 12){
				nLastDate = 31;
			} else if (nMonth == 2){
				if (this.gfn_isLeapYear(sDate) == true){
					nLastDate = 29;
				} else {
					nLastDate = 28;
				}
			} else {
				nLastDate = 30;
			}

			return nLastDate;
		},
		/**
		 * @class 윤년여부 확인
		 * @param sDate : yyyyMMdd형태의 날짜 ( 예 : "20121122" )
		 * @return sDate가 윤년인 경우 = true
		 *		   sDate가 윤년이 아닌 경우 = false
		 *		   sDate가 입력되지 않은 경우 = false
		 */  
		gfn_isLeapYear : function (sDate)
		{
			var ret;
			var nY;

			if (this.gfn_isNullEmpty(sDate)){
				return false;
			}

			nY = parseInt(sDate.substring(0, 4), 10);

			if ((nY % 4) == 0){
				if ((nY % 100) != 0 || (nY % 400) == 0){
					ret = true;
				} else {
					ret = false;
				}
			} else {
				ret = false;
			}

			return ret;
		},
		/**
		* nullToBlank(string)
		* 개    요 : null 일 경우 blank space return
		* return값 : String
		*/
		gfn_nullToBlank : function (sVal){
			if (this.gfn_isNullEmpty(sVal)){
				return "";
			} else {
				return sVal;
			}
		},
		/**
		* nullToZero()
		* 개    요 : null -> "0"
		* return값 : String
		*/
		gfn_nullToZero : function(sVal){
			if(this.gfn_isNullEmpty(sVal)||nexacro.trim(sVal) == '') {
				return "0";
			} else {
				return sVal;
			}
		},
		gfn_decode : function (code){
			for (var i=1; i<arguments.length; i+=2) {
				if (code == arguments[i]) {
					return arguments[i+1];
				}
			}
			
			return 	arguments[i-1];
		},
		gfn_iif : function ()
		{
			var varRtnValue = null;
			var arrArgument = this.lookup("iif").arguments;
			
			if (arrArgument[0]){
				return arrArgument[1];
			} else {
				return arrArgument[2];
			}
		},
		gfn_lpad : function(sValue, nLength, Char)
		{
			if (new String(sValue).valueOf() == "undefined") sValue = "";
			if (pUtil.gfn_isNullEmpty(sValue)) sValue = "";

			var strRetVal 	= new String(sValue);
			var strChar 	= "";
			var nIteration 	= nLength - strRetVal.length;

			for (var i = 0; i < nIteration; i++)
			{
				strChar = Char + strChar;
			}
			return (strChar + strRetVal);
		},
		gfn_rpad : function(sValue, nLength, Char)
		{
			if (new String(sValue).valueOf() == "undefined") sValue = "";
			if (pUtil.gfn_isNullEmpty(sValue)) sValue = "";

			var strRetVal 	= new String(sValue);
			var strChar 	= "";
			var nIteration 	= nLength - strRetVal.length;

			for (var i = 0; i < nIteration; i++)
			{
				strChar = strChar + Char;
			}
			return (strRetVal + strChar);
		},
		gfn_today : function ()
		{
			var strToday = "";
			var objDate = new Date();

			var strToday = objDate.getFullYear() + "";
			strToday += this.gfn_getRightStr("0" + (objDate.getMonth() + 1), 2);
			strToday += this.gfn_getRightStr("0" + objDate.getDate(), 2);

			return strToday;
		},
		gfn_getRightStr: function(source, length) 
		{
			if( source.length < length ) 
			{
				return source;
			} 
			else 
			{
				return source.substr(source.length-length, length);
			}
		},
		
		gfn_isExist: function(oThis, sFuncName)
		{
			var str = oThis[sFuncName];
			
			// 존재하지 않는 함수 체크
			if (pUtil.gfn_isNullEmpty(str)) {
				return false;
			} else {
				// 함수 타입인지 체크				
				if (typeof eval(str) == "function")				
				return true;
			} 
			
			return false;
		},
		
		gfn_lookup: function(p, name)
        {
            var o;
            while (p)
            {
                o = p.components;
                if (o && o[name]) return o[name];

                o = p.objects;
                if (o && o[name]) return o[name];

                p = p.parent;
            }
            return null;
        },
		
		/**
         * alphabet character code.
         * charvalue값 => [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, a, b, c, d, e, f]
         * @private
         * @constant
         * @memberOf utils
         */
        _ALPHA_CHAR_CODES: [48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 97, 98, 99, 100, 101, 102],
		
		gfn_getUniqueId: function(prefix, separator)
        {
            if (pUtil.gfn_isNullEmpty(prefix)) prefix = "";
            if (pUtil.gfn_isNullEmpty(separator))
            {
                separator = 45;
            }
            else
            {
                separator = separator.charCodeAt(0);
            }

            var charcode = this._ALPHA_CHAR_CODES,
                math = Math;
            var seq = 0;
            var seq0;
            var tmpArray = new Array(36);
            var idx = -1;

            while (seq < 8)
            {
                tmpArray[++idx] = charcode[math.random() * 16 | 0];
                seq++;
            }
            seq = 0;
            while (seq < 3)
            {
                tmpArray[++idx] = separator; //45 => "-", 95=> "_"
                seq0 = 0;
                while (seq0 < 4)
                {
                    tmpArray[++idx] = charcode[math.random() * 16 | 0];
                    seq0++;
                }
                seq++;
            }
            tmpArray[++idx] = separator; //45 => "-", 95=> "_"

            var tmpStr = (new Date()).getTime();
            tmpStr = ("0000000" + tmpStr.toString(16)).substr(-8);
            seq = 0;
            while (seq < 8)
            {
                tmpArray[++idx] = tmpStr.charCodeAt(seq);
                seq++;
            }
            seq = 0;
            while (seq < 4)
            {
                tmpArray[++idx] = charcode[math.random() * 16 | 0];
                seq++;
            }
            return prefix + String.fromCharCode.apply(null, tmpArray);
        },
        gfn_each: function(object, func, scope)
        {
            var p,
                scope = scope || object;
            for (p in object)
            {
                if (object.hasOwnProperty(p))
                {
                    if (func.call(scope, p, object[p], object) === false)
                    {
                        return;
                    }
                }
            }
        },
	}
}

this.dateFunc = function(){
	var context = this, utils;
	
	function toStr(val){
		return (val < 10) ? "0" + val : val;
	}
	
	utils = {
		gfn_weekName : ["일요일", "월요일", "화요일", "수요일", "목요일", "금요일", "토요일"],
		
		/* 
		 *  오늘 날짜를 받아오는 함수(서버에서 가져옴)
		 *  param - format : 가져올 포맷 - 기본값 "s"
		 *          type : 리턴받을 값의 타입
		 *				"d" : date 객체 (date 객체일 경우 앞의 format값은 무시)
		 *				"s" : 문자열
		 *
		 */
		
		gfn_today : function(format, type) {
			return (type == "d") ? utils.gfn_getDate() : utils.gfn_getDate().format(format);
		},		
		
		/*
		 *	입력받은 날짜를 포맷형식에 맞춰서 반환해준다.
		 *  param - d : 날짜 (string or date)
		 *				string 형식은 숫자를 제외한 나머지를 지우고 날짜 8자리 + 시간 6자리만 인식함. (ex - 20150101, 2015.01.01 둘을 같은 값으로 처리)
		 *		    f : 포맷 (기본값 : yyyymmdd)
		 *				yyyy - 년도 4자리
		 *				yy - 년도 2자리
		 *				mm - 월
		 *				dd - 일
		 *				HH - 시간(24시)
		 *				hh - 시간(12시)
		 *				mi - 분
		 *				ss - 초
		 *				ap - 오전/오후
		 *  return - 날짜 string
		 */
		gfn_format : function(d, f){
			// 인자값이 date객체가 string이면 객체로 변환
			d = (d instanceof Date) ? d : utils.gfn_getDate(d);
			f = f || "yyyymmdd";
			var h = "";
			
			return f.replace(/(yyyy|yy|mm|dd|E|hh|mi|ss|ap)/gi, function($1) {
				switch ($1) {
					case "yyyy": return d.getFullYear();
					case "yy": return toStr(d.getFullYear() % 1000);
					case "mm": return toStr(d.getMonth() + 1);
					case "dd": return toStr(d.getDate());
					case "E": return utils.gfn_weekName[d.getDay()];
					case "HH": return toStr(d.getHours());
					case "hh": return toStr((h = d.getHours() % 12) ? h : 12);
					case "mi": return toStr(d.getMinutes());
					case "ss": return toStr(d.getSeconds());
					case "ap": return d.getHours() < 12 ? "오전" : "오후";
					default: return $1;
				}
			});	
		},
		/*
		 *	날짜객체를 반환해준다.
		 *  param - strDate : 날짜 (string, 기본값 : 오늘날짜 * 서버시간 아님)
		 *			string 형식은 숫자를 제외한 나머지를 지우고 날짜 8자리(필수) + 시간 6자리(옵션)까지만 인식함. (ex - 20150101, 2015.01.01 둘을 같은 값으로 처리)
		 *  return - 날짜 date객체
		 */
		gfn_getDate : function(sDate){
			var date = new Date();
			if(sDate) {
				if(sDate == "server"){
					date = this.gfn_today("", "d");
				}else if(sDate instanceof Date){
					date = new Date(sDate);
				}else if(sDate instanceof nexacro.Date){		
					date = new Date(sDate.toString().substr(0,4), sDate.toString().substr(4,2) - 1, sDate.toString().substr(6,2));
				}else{			
					sDate = sDate.replace(/[^0-9]/gi, "");

					// 년 월만 넘어온 문자열인경우 (ex 201501) 01을 붙여준다.
					if(sDate.length == 6) {
						sDate += "01";
					}

					date = new Date(sDate.substr(0,4), sDate.substr(4,2) - 1, sDate.substr(6,2));
					
					(sDate.substr(8,2)) ? date.setHours(sDate.substr(8,2)) : date.setHours(0);
					(sDate.substr(10,2)) ? date.setMinutes(sDate.substr(10,2)) : date.setMinutes(0);
					(sDate.substr(12,2)) ? date.setSeconds(sDate.substr(12,2)) : date.setSeconds(0);
				}				
			}else{
				date = new Date();
			}			
			// date객체에 함수 바인드
			date.format = function(format){
				return utils.gfn_format(date, format);
			};
			date.addYear = function(val, type){
				return utils.gfn_addYear(date, val, type);
			};
			date.addMonth = function(val, type){
				return utils.gfn_addMonth(date, val, type);
			};
			date.addDate = function(val, type){
				return utils.gfn_addDate(date, val, type);
			};
			date.getLastDay = function(type){
				return utils.gfn_getLastDay(date, type);
			};
			return date;
		},
		/*
		 *	입력받은 날짜와 값을 입력받아서 해당 함수에 해당하는 만큼 더해준다.
		 *  param - date : (string or date) 날짜  * 날짜 객체를 파라미터로 쓴 경우 해당 객체의 값은 바꾸지 않고 새 date 객체를 반환
		 *          val  : 더할 값(숫자)
		 *          type : return 받을 값의 타입.  기본값 "d"
	     *					"d" : date객체
	     *					"s" : 문자열
		 *  return - date객체
		 */
		//년도를 더하는 함수
		gfn_addYear : function(date, val, type){
			var returnDate = utils.gfn_getDate(date);
			returnDate.setFullYear(returnDate.getFullYear() + val);
			return (type == "s") ? returnDate.format() : returnDate;
		},
		//월을 더하는 함수
		gfn_addMonth : function(date, val, type){
			var returnDate = utils.gfn_getDate(date);
			
			//월말인 경우 월을 더할 경우 해당월의 마지막날로 설정되도록 처리
			//(oracle add_month 펑션과 같은 결과를 출력)
			if(returnDate.format() == returnDate.getLastDay("s")){
				returnDate.setDate(1);
				returnDate.setMonth(returnDate.getMonth() + val + 1);
				returnDate.setDate(0);
			}else{
				returnDate.setMonth(returnDate.getMonth() + val);
			}
			return (type == "s") ? returnDate.format() : returnDate;
		},
		//일을 더하는 함수
		gfn_addDate : function(date, val, type){
			var returnDate = utils.gfn_getDate(date);
			returnDate.setDate(returnDate.getDate() + val);
			return (type == "s") ? returnDate.format() : returnDate;
		},
		
		/*
		 *	입력받은 두 날짜의 일자 수를 계산하여 반환(20150103, 20150101 입력 시 3 반환)
		 *  param - frDate : (string or date) 시작일
		 *          toDate : (string or date) 종료일
		 *  return - int 일자 수 : 시작일이 종료일보다 클 경우 -1 반환(시작일, 종료일이 같을 경우 1 반환)
		 */
		gfn_between : function(frDate, toDate){
			frDate = (frDate instanceof Date) ? frDate : utils.gfn_getDate(frDate);
			toDate = (toDate instanceof Date) ? toDate : utils.gfn_getDate(toDate);

			return (toDate >= frDate) ? Math.floor((toDate - frDate) / (1000 * 60 * 60 * 24)) + 1 : -1;
		},
		
		/*
		 *	입력받은 날짜를 기준으로 해당 월의 마지막 날을 반환
		 *  param - date : (string or date) 날짜
		 *          type : 반환 타입 ( s : 문자열
		 *							   d : date 개체 - 기본값)
		 *  return - 해당 날짜 월의 마지막 날을 반환 (ex - 20150502  -> 20150531,  20120203 -> 20120229)
		 */
		gfn_getLastDay : function(date, type){
			returnDate = utils.gfn_getDate(date);
			returnDate.setDate(1);
			returnDate.setMonth(returnDate.getMonth() + 1);
			returnDate.setDate(0);
			return (type == "s") ? returnDate.format() : returnDate;
		},
		/********************************************************************************
		 * Function Name    : gfn_getDayNum
		 * Desc             : 입력받은 날짜에 해당 하는 요일 number 을 반환
		 * Parameter        : sDate : (string or date) 날짜
		 * Return           : 요일(Number)
		 ********************************************************************************/
		gfn_getDayNum : function (sDate) 
		{	
			if (sDate instanceof nexacro.Date || sDate instanceof Date)
			{
				return sDate.getDay(); 
			}

			var objDate = this._strToDate(sDate);
			return objDate.getDay(); 
		},
		/********************************************************************************
		 * Function Name    : _strToDate
		 * Desc             : 날짜 문자열(String)을 Date객체로 변환
		 * Parameter        : sDate - (string or date) 날짜
		 * Return           : 문자열에 해당하는 Date객체
		 ********************************************************************************/
		_strToDate : function (sDate)
		{
			var nYear = parseInt(sDate.substr(0, 4));
			var nMonth = parseInt(sDate.substr(4, 2)) - 1;
			var nDate = parseInt(sDate.substr(6, 2));

			return new Date(nYear, nMonth, nDate);
		}
	}
	
	return utils;
};

var pUtil = this.utils();    //유틸
var pDate = this.dateFunc();