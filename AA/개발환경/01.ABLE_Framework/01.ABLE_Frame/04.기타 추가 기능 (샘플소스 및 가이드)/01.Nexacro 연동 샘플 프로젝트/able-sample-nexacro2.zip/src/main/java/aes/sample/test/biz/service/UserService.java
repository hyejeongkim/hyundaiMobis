package aes.sample.test.biz.service;

import java.util.List;

import aes.sample.test.biz.vo.DefaultVO;
import aes.sample.test.biz.vo.UserVO;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName   : UserService.java
 * @Description : 클래스 설명을 기술합니다.
 * @author Autoever
 * @since 2017. 10. 31.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2017. 10. 31.     Autoever     	최초 생성
 * </pre>
 */
public interface UserService {

    UserVO selectUserVO(String userId) throws Exception;
    
    int updateUserVO(UserVO userVO) throws Exception;
    
    int insertUserVO(UserVO userVO) throws Exception;
    
    int deleteUserVO(String userId) throws Exception;
    
    List<UserVO> selectUserVOList(DefaultVO searchVO) throws Exception;

    void multiUserVO(UserVO userVO) throws Exception;
    
    void multiUserVOList(List<UserVO> userVO) throws Exception;

}
