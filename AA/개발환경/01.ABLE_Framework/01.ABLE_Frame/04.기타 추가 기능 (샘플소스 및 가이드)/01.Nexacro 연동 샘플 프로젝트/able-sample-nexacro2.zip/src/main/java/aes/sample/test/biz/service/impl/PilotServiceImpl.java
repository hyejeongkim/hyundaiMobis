package aes.sample.test.biz.service.impl;

import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import able.com.ui.adaptor.nexacro.data.DataSetRowTypeAccessor;
import able.com.vo.HMap;

import org.springframework.stereotype.Service;

import com.nexacro.xapi.data.DataSet;

import aes.sample.test.biz.service.PilotService;
import aes.sample.test.biz.service.dao.PilotMDAO;
import aes.sample.test.biz.vo.PilotVO;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName   : PilotServiceImpl.java
 * @Description : 클래스 설명을 기술합니다.
 * @author JCH
 * @since 2017. 7. 10.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2017. 7. 10.     JCH     	최초 생성
 * </pre>
 */

@Service("pilotService")
public class PilotServiceImpl implements PilotService {

    @Resource(name = "pilotMDAO")
    private PilotMDAO pilotMDAO;
    
    /*
     * @see aes.sample.test.biz.service.PilotService#searchUserList(aes.sample.test.biz.vo.PilotVO)
     */
    @Override
    public List<HMap> searchUserList(Map searchMap) throws Exception{
        return pilotMDAO.searchUserList(searchMap);
    }
    
    @Override
    public List<PilotVO> searchUserVOList(Map searchMap) throws Exception{
        return pilotMDAO.searchUserVOList(searchMap);
    }

    /*
     * @see aes.sample.test.biz.service.PilotService#selectUserInfo(aes.sample.test.biz.vo.PilotVO)
     */
    @Override
    public PilotVO selectUserInfo(PilotVO pilotVO) throws Exception{
        return pilotMDAO.selectUserInfo(pilotVO);
    }
    
    
    @Override
    public int saveUserInfo(List<Map> saveMap) throws Exception{
        int result = 0;
        
        for(int i=0;i<saveMap.size();i++){
            Map hmap = (Map) saveMap.get(i);
            if(hmap.get("DataSetRowType").equals(DataSet.ROW_TYPE_INSERTED)){
                result += pilotMDAO.insertUserInfo(hmap);
            }else if (hmap.get("DataSetRowType").equals(DataSet.ROW_TYPE_UPDATED)){
                result += pilotMDAO.updateUserInfo(hmap);
            }else if (hmap.get("DataSetRowType").equals(DataSet.ROW_TYPE_DELETED)){
                result += pilotMDAO.deleteUserInfo(hmap);
            }
            
        }
        
        /*if (pilotVO instanceof DataSetRowTypeAccessor){
            DataSetRowTypeAccessor accessor = (DataSetRowTypeAccessor) pilotVO;
            
            if (accessor.getRowType() == DataSet.ROW_TYPE_INSERTED){
                int dupCnt = pilotMDAO.selectUserIdDupChk(pilotVO);
                if ( dupCnt > 0 ) {
                    //throw new Exception ("duplication error");
                    System.out.println("########################### duplication error");
                } else {
                    result += pilotMDAO.insertUserInfo(pilotVO);
                //}
                
            }else if (accessor.getRowType() == DataSet.ROW_TYPE_UPDATED){
                result += pilotMDAO.updateUserInfo(pilotVO);
            }else if (accessor.getRowType() == DataSet.ROW_TYPE_DELETED){
                result += pilotMDAO.deleteUserInfo(pilotVO);
            }
        }*/
        return result;
    }
    
    @Override
    public int saveUserList(List<Map> saveMapList) throws Exception{
        int result = 0 ;
        
        for(int i=0;i<saveMapList.size();i++){
            Map hmap = (Map) saveMapList.get(i);
            if(hmap.get("rowType").equals(DataSet.ROW_TYPE_INSERTED)){
                result += pilotMDAO.insertUserInfo(hmap);
            }else if (hmap.get("rowType").equals(DataSet.ROW_TYPE_UPDATED)){
                result += pilotMDAO.updateUserInfo(hmap);
            }else if (hmap.get("rowType").equals(DataSet.ROW_TYPE_DELETED)){
                result += pilotMDAO.deleteUserInfo(hmap);
            }
            
        }
        /*for ( int i = 0 ; i < pilotVOList.size() ; i++ ) {
            PilotVO user = pilotVOList.get(i);
            
            if ( user instanceof DataSetRowTypeAccessor ) {
                DataSetRowTypeAccessor accessor = (DataSetRowTypeAccessor) user;

                if (accessor.getRowType() == DataSet.ROW_TYPE_INSERTED){
                    result += pilotMDAO.insertUserInfo(user);
                }else if (accessor.getRowType() == DataSet.ROW_TYPE_UPDATED){
                    result += pilotMDAO.updateUserInfo(user);
                }else if (accessor.getRowType() == DataSet.ROW_TYPE_DELETED){
                    result += pilotMDAO.deleteUserInfo(user);
                }
            }
        }*/
        
        return result;
    }
}
