package aes.sample.test.biz.vo;

/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName   : PilotVO.java
 * @Description : 클래스 설명을 기술합니다.
 * @author JCH
 * @since 2017. 7. 10.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2017. 7. 10.     JCH     	최초 생성
 * </pre>
 */

public class PilotVO extends DefaultVO {

    private String userId;
    private String userName;
    private String enName;
    private String cellPhone;
    private String company;
    private String jobPosition;
    private String officerYn;
    private String compZipCode;
    private String compAddress;
    private String email;
    private String deptId;
    private String password;
    private String birthDay;
    private String chk;
    private String bossId;
    private String bossNm;
    private String useYn;
    
    /**
     * @return the userId
     */
    public String getUserId() {
        return userId;
    }
    /**
     * @param userId the userId to set
     */
    public void setUserId(String userId) {
        this.userId = userId;
    }
    /**
     * @return the userName
     */
    public String getUserName() {
        return userName;
    }
    /**
     * @param userName the userName to set
     */
    public void setUserName(String userName) {
        this.userName = userName;
    }
    /**
     * @return the enName
     */
    public String getEnName() {
        return enName;
    }
    /**
     * @param enName the enName to set
     */
    public void setEnName(String enName) {
        this.enName = enName;
    }
    /**
     * @return the cellPhone
     */
    public String getCellPhone() {
        return cellPhone;
    }
    /**
     * @param cellPhone the cellPhone to set
     */
    public void setCellPhone(String cellPhone) {
        this.cellPhone = cellPhone;
    }
    /**
     * @return the company
     */
    public String getCompany() {
        return company;
    }
    /**
     * @param company the company to set
     */
    public void setCompany(String company) {
        this.company = company;
    }
    /**
     * @return the jobPosition
     */
    public String getJobPosition() {
        return jobPosition;
    }
    /**
     * @param jobPosition the jobPosition to set
     */
    public void setJobPosition(String jobPosition) {
        this.jobPosition = jobPosition;
    }
    /**
     * @return the officerYn
     */
    public String getOfficerYn() {
        return officerYn;
    }
    /**
     * @param officerYn the officerYn to set
     */
    public void setOfficerYn(String officerYn) {
        this.officerYn = officerYn;
    }
    /**
     * @return the compZipCode
     */
    public String getCompZipCode() {
        return compZipCode;
    }
    /**
     * @param compZipCode the compZipCode to set
     */
    public void setCompZipCode(String compZipCode) {
        this.compZipCode = compZipCode;
    }
    /**
     * @return the compAddress
     */
    public String getCompAddress() {
        return compAddress;
    }
    /**
     * @param compAddress the compAddress to set
     */
    public void setCompAddress(String compAddress) {
        this.compAddress = compAddress;
    }
    /**
     * @return the email
     */
    public String getEmail() {
        return email;
    }
    /**
     * @param email the email to set
     */
    public void setEmail(String email) {
        this.email = email;
    }
    /**
     * @return the deptId
     */
    public String getDeptId() {
        return deptId;
    }
    /**
     * @param deptId the deptId to set
     */
    public void setDeptId(String deptId) {
        this.deptId = deptId;
    }
    /**
     * @return the password
     */
    public String getPassword() {
        return password;
    }
    /**
     * @param password the password to set
     */
    public void setPassword(String password) {
        this.password = password;
    }
    /**
     * @return the birthDay
     */
    public String getBirthDay() {
        return birthDay;
    }
    /**
     * @param birthDay the birthDay to set
     */
    public void setBirthDay(String birthDay) {
        this.birthDay = birthDay;
    }
    /**
     * @return the chk
     */
    public String getChk() {
        return chk;
    }
    /**
     * @param chk the chk to set
     */
    public void setChk(String chk) {
        this.chk = chk;
    }
    /**
     * @return the bossId
     */
    public String getBossId() {
        return bossId;
    }
    /**
     * @param bossId the bossId to set
     */
    public void setBossId(String bossId) {
        this.bossId = bossId;
    }
    /**
     * @return the bossNm
     */
    public String getBossNm() {
        return bossNm;
    }
    /**
     * @param bossNm the bossNm to set
     */
    public void setBossNm(String bossNm) {
        this.bossNm = bossNm;
    }
    /**
     * @return the useYn
     */
    public String getUseYn() {
        return useYn;
    }
    /**
     * @param useYn the useYn to set
     */
    public void setUseYn(String useYn) {
        this.useYn = useYn;
    }
    
}
