package aes.sample.test.biz.authority;

/**
 * <pre>
 * 권한 및 인증 실패시 발생하는 예외
 * </pre>
 * 
 * @ClassName : AuthorityException.java
 * @author Park SeongMin
 * @since 2016. 4. 5.
 * @version 1.0
 * @see
 * @Modification Information
 * 
 *               <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2016. 4. 5.     Park SeongMin     최초 생성
 * </pre>
 */

public class AuthorityException extends Exception {

    /**
     * 기본 생성자이다.
     */
    public AuthorityException() {
        ;
    }

    /**
     * 메시지를 가지는 생성자이다.
     * 
     * @param message
     *            메시지
     */
    public AuthorityException(String message) {
        super(message);
    }

    /**
     * 메시지와 원천(cause) 예외를 가지는 생성자이다.
     * 
     * @param message
     *            메시지
     * @param cause
     *            원천 예외
     */
    public AuthorityException(String message, Throwable cause) {
        super(message, cause);
    }

}
