package aes.sample.test.biz.service.impl;

import java.util.List;

import javax.annotation.Resource;

import able.com.service.HService;

import org.springframework.stereotype.Service;

import able.com.ui.adaptor.nexacro.data.DataSetRowTypeAccessor;
import com.nexacro.xapi.data.DataSet;

import aes.sample.test.biz.service.UserService;
import aes.sample.test.biz.service.dao.UserMDAO;
import aes.sample.test.biz.vo.DefaultVO;
import aes.sample.test.biz.vo.UserVO;


/**
 * <pre>
 * Statements
 * </pre>
 *
 * @ClassName   : UserServiceImpl.java
 * @Description : 클래스 설명을 기술합니다.
 * @author Autoever
 * @since 2017. 10. 31.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2017. 10. 31.     Autoever     	최초 생성
 * </pre>
 */
@Service("userService")
public class UserServiceImpl extends HService implements UserService {

    /**
     * UserDAO class 선언 (UserDAO) Class Injection)
     * (UserDAO)sampleDAO
     */
    // @Autowired(required = false) // Type 정의
    @Resource(name = "userMDAO")
    private UserMDAO userMDAO;

    @Override
    public UserVO selectUserVO(String userId)  throws Exception{
        return userMDAO.selectUserVO(userId);
    }
    
    @Override
    public int updateUserVO(UserVO userVO)  throws Exception{
        return userMDAO.updateUserVO(userVO);
    }
    
    @Override
    public int insertUserVO(UserVO userVO)  throws Exception{
        return userMDAO.insertUserVO(userVO);
    }
    
    @Override
    public int deleteUserVO(String userId)  throws Exception{
        return userMDAO.deleteUserVO(userId);
    }
    
    @Override
    public List<UserVO> selectUserVOList(DefaultVO searchVO)  throws Exception{
        return userMDAO.selectUserVOList(searchVO);
    }

    @Override
    public void multiUserVO(UserVO userVO)  throws Exception{

        /*int size = modifyList.size();
        for (int i=0; i<size; i++) {
            UserVO user = modifyList.get(i);*/
            if (userVO instanceof DataSetRowTypeAccessor){
                DataSetRowTypeAccessor accessor = (DataSetRowTypeAccessor) userVO;
                
                if (accessor.getRowType() == DataSet.ROW_TYPE_INSERTED){
                    userMDAO.insertUserVO(userVO);
                }else if (accessor.getRowType() == DataSet.ROW_TYPE_UPDATED){
                    userMDAO.updateUserVO(userVO);
                }else if (accessor.getRowType() == DataSet.ROW_TYPE_DELETED){
                    userMDAO.deleteUserVO(userVO.getUserId());
                }
            }
            
       // }
    }
    
    @Override
    public void multiUserVOList(List<UserVO> modifyList)  throws Exception{

        int size = modifyList.size();
        for (int i=0; i<size; i++) {
            UserVO user = modifyList.get(i);
            if (user instanceof DataSetRowTypeAccessor){
                DataSetRowTypeAccessor accessor = (DataSetRowTypeAccessor) user;
                
                if (accessor.getRowType() == DataSet.ROW_TYPE_INSERTED){
                    userMDAO.insertUserVO(user);
                }else if (accessor.getRowType() == DataSet.ROW_TYPE_UPDATED){
                    userMDAO.updateUserVO(user);
                }else if (accessor.getRowType() == DataSet.ROW_TYPE_DELETED){
                    userMDAO.deleteUserVO(user.getUserId());
                }
            }
            
        }
    }
}
