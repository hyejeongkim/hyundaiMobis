package aes.sample.test.biz.authority;

import java.util.Map;

import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.web.servlet.view.AbstractView;

/**
 * <pre>
 * 권한 및 인증 오류 시 nexacro로 데이터 전송을 위한 View이다.
 * </pre>
 * 
 * @ClassName : UnAuthorizedView.java
 * @author Park SeongMin
 * @since 2016. 4. 5.
 * @version 1.0
 * @see
 * @Modification Information
 * 
 *               <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2016. 4. 5.     Park SeongMin     최초 생성
 * </pre>
 */

public class UnAuthorizedView extends AbstractView {

    @Override
    protected void renderMergedOutputModel(Map<String, Object> model,  HttpServletRequest request, HttpServletResponse response)
            throws Exception {
        
        // response.sendError(401, "unauthorized"); 
        
        String responseData = "<html><body>unauthorized</body><html>";
        ServletOutputStream outputStream = response.getOutputStream();
        outputStream.write(responseData.getBytes());
        outputStream.flush();
        
    }

}
