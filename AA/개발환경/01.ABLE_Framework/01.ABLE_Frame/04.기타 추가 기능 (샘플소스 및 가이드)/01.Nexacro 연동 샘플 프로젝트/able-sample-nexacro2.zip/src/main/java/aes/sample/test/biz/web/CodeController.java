package aes.sample.test.biz.web;

import java.util.List;

import javax.annotation.Resource;

import able.com.ui.adaptor.annotation.ParamDataSet;
import able.com.ui.adaptor.nexacro.data.NexacroResult;
import able.com.web.HController;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import aes.sample.test.biz.service.CodeService;
import aes.sample.test.biz.vo.CodeVO;
import aes.sample.test.biz.vo.GroupCodeVO;

/**
 * <pre>
 * Code 처리를 위한 Controller
 * </pre>
 *
 * @ClassName   : CodeController.java
 * @Description : Sample Controller Class
 * @author Park SeongMin
 * @since 2015. 9. 11.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2015. 9. 11.     Park SeongMin     최초 생성
 * </pre>
 */
@Controller
public class CodeController extends HController {

    @Resource(name = "codeService")
    private CodeService codeService;
    
    /**
     * 
     * Code를 조회 한다.
     *
     * @param searchVOList
     * @return
     */
    @RequestMapping(value = "/selectCodeGroupList.do")
    public NexacroResult selectCodeGroupList(@ParamDataSet(name="ds_search") List<GroupCodeVO> searchVOList
            , NexacroResult result){
        
        GroupCodeVO searchVo = null;
        if(searchVOList != null && searchVOList.size() > 0) {
            searchVo = searchVOList.get(0);
        }
        
        List<GroupCodeVO> groupCodeList = codeService.selectCodeGroupList(searchVo);
        
        List<CodeVO> codeList = codeService.selectCodeList();
        
        result.addDataSet("dsGroupCode", groupCodeList);
        result.addDataSet("dsCode", codeList);
        
        return result;
    }
    
    /**
     * 
     * Code를 수정한다.
     *
     * @param modifyGroupList
     * @param modifyCodeList
     * @return
     */
    @RequestMapping(value = "/multiCodes.do")
    public NexacroResult multiCodes(@ParamDataSet(name="dsGroupCode") List<GroupCodeVO> modifyGroupList
                            , @ParamDataSet(name="dsCode") List<CodeVO> modifyCodeList
                            , NexacroResult result){
        
        codeService.modifyCodeGroup(modifyGroupList);
        codeService.modifyCode(modifyCodeList);        
       
        return result;
    }
    
}
