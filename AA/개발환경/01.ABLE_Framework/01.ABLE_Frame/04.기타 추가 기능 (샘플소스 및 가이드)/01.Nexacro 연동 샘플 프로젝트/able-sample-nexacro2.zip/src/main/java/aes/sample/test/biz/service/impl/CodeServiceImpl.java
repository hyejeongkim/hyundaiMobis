package aes.sample.test.biz.service.impl;

import java.util.List;

import javax.annotation.Resource;

import able.com.ui.adaptor.nexacro.data.DataSetRowTypeAccessor;

import org.springframework.stereotype.Service;

import com.nexacro.xapi.data.DataSet;

import aes.sample.test.biz.service.CodeService;
import aes.sample.test.biz.service.dao.CodeMDAO;
import aes.sample.test.biz.vo.CodeVO;
import aes.sample.test.biz.vo.GroupCodeVO;

/**
 * <pre>
 * Test를 위한 ServiceImpl Sample Class
 * </pre>
 *
 * @ClassName   : CodeServiceImpl.java
 * @Description : service impl
 * @author Park SeongMin
 * @since 2015. 9. 11.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2015. 9. 11.     Park SeongMin     최초 생성
 * </pre>
 */
@Service("codeService")
public class CodeServiceImpl implements CodeService {

    @Resource(name = "codeMDAO")
    private CodeMDAO codeMDAO;

    @Override
    public List<GroupCodeVO> selectCodeGroupList(GroupCodeVO searchVo) {
        return codeMDAO.selectCodeGroupList(searchVo);
    }

    @Override
    public List<CodeVO> selectCodeList() {
        return codeMDAO.selectCodeList();
    }

    @Override
    public void modifyCodeGroup(List<GroupCodeVO> modifyVOList) {

        int size = modifyVOList.size();
        for (int i=0; i<size; i++) {
            GroupCodeVO group = modifyVOList.get(i);
            if (group instanceof DataSetRowTypeAccessor){
                DataSetRowTypeAccessor accessor = (DataSetRowTypeAccessor) group;
                
                if (accessor.getRowType() == DataSet.ROW_TYPE_INSERTED){
                    insertGroupCodeVO(group);
                }else if (accessor.getRowType() == DataSet.ROW_TYPE_UPDATED){
                    updateGroupCodeVO(group);
                }else if (accessor.getRowType() == DataSet.ROW_TYPE_DELETED){
                    deleteGroupCodeVO(group);
                }
            }
            
        }
    }

    public void insertGroupCodeVO(GroupCodeVO groupCodeVO) {
        codeMDAO.insertGroupCodeVO(groupCodeVO);
    }
    
    public void updateGroupCodeVO(GroupCodeVO groupCodeVO) {
        codeMDAO.updateGroupCodeVO(groupCodeVO);
    }
    
    public void deleteGroupCodeVO(GroupCodeVO groupCodeVO) {
        codeMDAO.deleteGroupCodeVO(groupCodeVO);
    }
    
    @Override
    public void modifyCode(List<CodeVO> modifyVOList) {
        int size = modifyVOList.size();
        for (int i=0; i<size; i++) {
            CodeVO code = modifyVOList.get(i);
            if (code instanceof DataSetRowTypeAccessor){
                DataSetRowTypeAccessor accessor = (DataSetRowTypeAccessor) code;
                
                if (accessor.getRowType() == DataSet.ROW_TYPE_INSERTED){
                    insertCodeVO(code);
                }else if (accessor.getRowType() == DataSet.ROW_TYPE_UPDATED){
                    updateCodeVO(code);
                }else if (accessor.getRowType() == DataSet.ROW_TYPE_DELETED){
                    deleteCodeVO(code);
                }
            }
            
        }
    }

    public void insertCodeVO(CodeVO codeVO) {
        codeMDAO.insertCodeVO(codeVO);
    }
    
    public void updateCodeVO(CodeVO codeVO) {
        codeMDAO.updateCodeVO(codeVO);
    }
    
    public void deleteCodeVO(CodeVO codeVO) {
        codeMDAO.deleteCodeVO(codeVO);
    }
}
