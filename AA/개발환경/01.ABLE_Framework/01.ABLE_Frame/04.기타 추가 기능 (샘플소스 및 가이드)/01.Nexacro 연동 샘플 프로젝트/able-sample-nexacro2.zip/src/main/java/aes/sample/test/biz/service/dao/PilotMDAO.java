package aes.sample.test.biz.service.dao;

import java.util.List;
import java.util.Map;

import able.com.mybatis.Mapper;
import able.com.vo.HMap;

import aes.sample.test.biz.vo.PilotVO;

/**
 * <pre>
 * Statements
 * </pre>
 * 
 * @ClassName   : PilotDAO.java
 * @Description : 클래스 설명을 기술합니다.
 * @author JCH
 * @since 2017. 7. 10.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2017. 7. 10.     JCH     	최초 생성
 * </pre>
 */

@Mapper("pilotMDAO")
public interface PilotMDAO {

    List<HMap> searchUserList(Map searchMap) throws Exception;
    
    List<PilotVO> searchUserVOList(Map searchMap) throws Exception;

    int insertUserInfo(Map hmap) throws Exception;

    int updateUserInfo(Map hmap) throws Exception;
    
    int deleteUserInfo(Map hmap) throws Exception;
    
    PilotVO selectUserInfo(PilotVO pilotVO) throws Exception;
}
