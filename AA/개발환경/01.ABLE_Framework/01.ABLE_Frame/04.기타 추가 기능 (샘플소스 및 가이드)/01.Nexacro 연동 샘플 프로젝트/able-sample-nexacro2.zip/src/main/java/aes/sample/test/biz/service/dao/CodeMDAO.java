package aes.sample.test.biz.service.dao;

import java.util.List;

import able.com.mybatis.Mapper;
import able.com.ui.adaptor.nexacro.dao.mybatis.NexacroHsqlAbstractDAO;

import org.springframework.stereotype.Repository;

import aes.sample.test.biz.vo.CodeVO;
import aes.sample.test.biz.vo.GroupCodeVO;

/**
 * <pre>
 * Test를 위한 DAO Sample Class
 * </pre>
 *
 * @ClassName   : java
 * @Description : Sample DAO Class
 * @author Park SeongMin
 * @since 2015. 9. 11.
 * @version 1.0
 * @see
 * @Modification Information
 * <pre>
 *     since          author              description
 *  ===========    =============    ===========================
 *  2015. 9. 11.     Park SeongMin     최초 생성
 * </pre>
 */
@Mapper("codeMDAO")
public interface CodeMDAO {

    public List<GroupCodeVO> selectCodeGroupList(GroupCodeVO searchVO);

    public List<CodeVO> selectCodeList();

    public void insertGroupCodeVO(GroupCodeVO groupCodeVO);

    public void updateGroupCodeVO(GroupCodeVO groupCodeVO);

    public void deleteGroupCodeVO(GroupCodeVO groupCodeVO);
    
    public void insertCodeVO(CodeVO codeVO);

    public void updateCodeVO(CodeVO codeVO);

    public void deleteCodeVO(CodeVO codeVO);    
    
    
}
