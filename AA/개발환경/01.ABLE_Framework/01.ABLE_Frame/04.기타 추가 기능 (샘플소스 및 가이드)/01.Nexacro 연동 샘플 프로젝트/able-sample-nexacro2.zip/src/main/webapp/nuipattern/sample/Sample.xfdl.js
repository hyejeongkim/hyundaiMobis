﻿(function()
{
    return function()
    {
        if (!this._is_form)
            return;
        
        this.on_create = function()
        {
            // Declare Reference
            var obj = null;
            
            if (Form == this.constructor) {
                this.set_name("Sample");
                this.set_classname("Sample");
                this.set_titletext("SampleForm");
                this._setFormPosition(0,0,1024,768);
            }

            
            // Object(Dataset, ExcelExportObject) Initialize
            obj = new Dataset("ds_data", this);
            obj._setContents("<ColumnInfo><Column id=\"gubun\" type=\"STRING\" size=\"256\"/><Column id=\"menuId\" type=\"STRING\" size=\"256\"/><Column id=\"menuNm\" type=\"STRING\" size=\"256\"/><Column id=\"sort\" type=\"STRING\" size=\"256\"/><Column id=\"useYn\" type=\"STRING\" size=\"256\"/><Column id=\"auth\" type=\"STRING\" size=\"256\"/><Column id=\"period\" type=\"STRING\" size=\"256\"/></ColumnInfo>");
            this.addChild(obj.name, obj);

            obj = new Dataset("ds_combo", this);
            obj._setContents("<ColumnInfo><Column id=\"code\" type=\"STRING\" size=\"256\"/><Column id=\"codeNm\" type=\"STRING\" size=\"256\"/></ColumnInfo><Rows><Row><Col id=\"code\">A</Col><Col id=\"codeNm\">선택01</Col></Row><Row><Col id=\"code\">B</Col><Col id=\"codeNm\">선택02</Col></Row><Row><Col id=\"code\">C</Col><Col id=\"codeNm\">선택03</Col></Row></Rows>");
            this.addChild(obj.name, obj);


            
            // UI Components Initialize
            obj = new GroupBox("GroupBox00", "absolute", "1.07%", "50", null, "285", "24.41%", null, this);
            obj.set_text("메뉴등록");
            obj.set_taborder("25");
            this.addChild(obj.name, obj);

            obj = new Combo("Combo00", "absolute", "5.66%", "10", null, "22", "82.52%", null, this);
            this.addChild(obj.name, obj);
            obj.set_taborder("0");
            obj.set_text("선택01");
            obj.set_innerdataset("@ds_combo");
            obj.set_codecolumn("code");
            obj.set_datacolumn("codeNm");
            obj.set_value("A");
            obj.set_index("0");

            obj = new Button("btnSearch", "absolute", "65.23%", "16", null, "22", "25.49%", null, this);
            obj.set_taborder("1");
            obj.set_text("조회");
            this.addChild(obj.name, obj);

            obj = new Grid("Grid00", "absolute", "1.37%", "379", null, "235", "24.71%", null, this);
            obj.set_taborder("2");
            obj.set_binddataset("dsData");
            obj.set_autofittype("none");
            obj._setContents("<Formats><Format id=\"default\"><Columns><Column size=\"80\"/><Column size=\"80\"/><Column size=\"80\"/><Column size=\"80\"/><Column size=\"80\"/><Column size=\"80\"/><Column size=\"80\"/></Columns><Rows><Row size=\"24\" band=\"head\"/><Row size=\"24\"/></Rows><Band id=\"head\"><Cell text=\"구분\"/><Cell col=\"1\" text=\"메뉴ID\"/><Cell col=\"2\" text=\"메뉴명\"/><Cell col=\"3\" text=\"순서\"/><Cell col=\"4\" text=\"권한1\"/><Cell col=\"5\" text=\"권한2\"/><Cell col=\"6\" text=\"첨부파일\"/><Cell col=\"7\" text=\"기간\"/></Band><Band id=\"body\"><Cell displaytype=\"tree\" edittype=\"tree\" text=\"bind:test1\" treelevel=\"bind:test1\" treecheck=\"bind:test1\"/><Cell col=\"1\" text=\"bind:menuId\"/><Cell col=\"2\" text=\"bind:menuNm\"/><Cell col=\"3\" text=\"bind:sort\"/><Cell col=\"4\" text=\"bind:auth\"/><Cell col=\"5\" text=\"bind:auth\"/><Cell col=\"6\"/><Cell col=\"7\" text=\"bind:test6\"/></Band></Format></Formats>");
            this.addChild(obj.name, obj);

            obj = new CheckBox("chkUseYn", "absolute", "33.69%", "9", null, "23", "55.27%", null, this);
            obj.set_taborder("3");
            obj.set_text("사용여부 ");
            this.addChild(obj.name, obj);

            obj = new Calendar("Calendar00", "absolute", "22.75%", "7", null, "27", "67.87%", null, this);
            this.addChild(obj.name, obj);
            obj.set_taborder("4");

            obj = new Static("Static00", "absolute", "2.44%", "81", null, "25", "89.36%", null, this);
            obj.set_taborder("5");
            obj.set_text("MENU ID *");
            this.addChild(obj.name, obj);

            obj = new Static("Static01", "absolute", "2.44%", "106", null, "25", "89.36%", null, this);
            obj.set_taborder("6");
            obj.set_text("분류");
            this.addChild(obj.name, obj);

            obj = new Static("Static02", "absolute", "2.44%", "131", null, "25", "89.36%", null, this);
            obj.set_taborder("7");
            obj.set_text("메뉴명");
            this.addChild(obj.name, obj);

            obj = new Static("Static03", "absolute", "2.44%", "156", null, "25", "89.36%", null, this);
            obj.set_taborder("8");
            obj.set_text("순서");
            this.addChild(obj.name, obj);

            obj = new Static("Static04", "absolute", "2.44%", "181", null, "25", "89.36%", null, this);
            obj.set_taborder("9");
            obj.set_text("사용여부");
            this.addChild(obj.name, obj);

            obj = new Static("Static05", "absolute", "19.04%", "7", null, "27", "77.83%", null, this);
            obj.set_taborder("10");
            obj.set_text("날짜");
            this.addChild(obj.name, obj);

            obj = new Static("Static06", "absolute", "2.44%", "208", null, "25", "89.36%", null, this);
            obj.set_taborder("11");
            obj.set_text("권한");
            this.addChild(obj.name, obj);

            obj = new Static("Static07", "absolute", "2.44%", "236", null, "25", "89.36%", null, this);
            obj.set_taborder("12");
            obj.set_text("기간");
            this.addChild(obj.name, obj);

            obj = new Static("Static08", "absolute", "2.44%", "270", null, "25", "89.36%", null, this);
            obj.set_taborder("13");
            obj.set_text("파일업로드");
            this.addChild(obj.name, obj);

            obj = new Edit("menuId", "absolute", "10.06%", "86", "100", "20", null, null, this);
            obj.set_taborder("15");
            this.addChild(obj.name, obj);

            obj = new Combo("Combo01", "absolute", "10.06%", "111", "100", "20", null, null, this);
            this.addChild(obj.name, obj);
            obj.set_taborder("16");
            obj.set_text("Combo01");

            obj = new Edit("Edit01", "absolute", "10.06%", "136", "100", "20", null, null, this);
            obj.set_taborder("17");
            this.addChild(obj.name, obj);

            obj = new Edit("Edit02", "absolute", "10.06%", "161", "100", "20", null, null, this);
            obj.set_taborder("18");
            this.addChild(obj.name, obj);

            obj = new Radio("Radio00", "absolute", "10.06%", "186", "142", "20", null, null, this);
            this.addChild(obj.name, obj);
            var Radio00_innerdataset = new Dataset("Radio00_innerdataset", this.Radio00);
            Radio00_innerdataset._setContents("<ColumnInfo><Column id=\"codecolumn\" size=\"256\"/><Column id=\"datacolumn\" size=\"256\"/></ColumnInfo><Rows><Row><Col id=\"codecolumn\">Y</Col><Col id=\"datacolumn\">사용</Col></Row><Row><Col id=\"codecolumn\">N</Col><Col id=\"datacolumn\">미사용</Col></Row></Rows>");
            obj.set_innerdataset(Radio00_innerdataset);
            obj.set_taborder("19");
            obj.set_direction("vertical");
            obj.set_codecolumn("codecolumn");
            obj.set_datacolumn("datacolumn");

            obj = new CheckBox("CheckBox01", "absolute", "10.06%", "211", "72", "20", null, null, this);
            obj.set_taborder("20");
            obj.set_text("권한1");
            this.addChild(obj.name, obj);

            obj = new Calendar("Calendar01", "absolute", "21.88%", "236", "100", "20", null, null, this);
            this.addChild(obj.name, obj);
            obj.set_taborder("21");

            obj = new Calendar("Calendar02", "absolute", "10.06%", "236", "100", "20", null, null, this);
            this.addChild(obj.name, obj);
            obj.set_taborder("22");

            obj = new CheckBox("CheckBox02", "absolute", "16.31%", "211", "72", "20", null, null, this);
            obj.set_taborder("23");
            obj.set_text("권한2");
            this.addChild(obj.name, obj);

            obj = new Static("Static09", "absolute", "20.41%", "233", null, "25", "78.71%", null, this);
            obj.set_taborder("24");
            obj.set_text("~");
            this.addChild(obj.name, obj);

            obj = new Button("Button01", "absolute", "65.23%", "64", null, "22", "25.49%", null, this);
            obj.set_taborder("26");
            obj.set_text("저장");
            this.addChild(obj.name, obj);

            obj = new Button("Button02", "absolute", "55.86%", "344", null, "22", "34.86%", null, this);
            obj.set_taborder("27");
            obj.set_text("저장");
            this.addChild(obj.name, obj);

            obj = new Static("Static10", "absolute", "2.05%", "7", null, "27", "94.82%", null, this);
            obj.set_taborder("28");
            obj.set_text("구분");
            this.addChild(obj.name, obj);

            obj = new Button("Button03", "absolute", "66.02%", "344", null, "22", "24.71%", null, this);
            obj.set_taborder("29");
            obj.set_text("삭제");
            this.addChild(obj.name, obj);

            obj = new Button("Button04", "absolute", "45.7%", "344", null, "22", "45.02%", null, this);
            obj.set_taborder("30");
            obj.set_text("입력");
            this.addChild(obj.name, obj);

            obj = new Static("Static12", "absolute", "2.44%", "302", null, "25", "89.36%", null, this);
            obj.set_taborder("32");
            obj.set_text("엑셀업로드");
            this.addChild(obj.name, obj);

            obj = new Edit("Edit04", "absolute", "10.35%", "304", null, "14", "72.56%", null, this);
            obj.set_taborder("34");
            this.addChild(obj.name, obj);

            obj = new Button("Button06", "absolute", "27.83%", "303", null, "17", "65.53%", null, this);
            obj.set_taborder("36");
            obj.set_text("파일찾기");
            this.addChild(obj.name, obj);

            obj = new Button("Button07", "absolute", "55.08%", "64", null, "22", "35.64%", null, this);
            obj.set_taborder("37");
            obj.set_text("초기화");
            this.addChild(obj.name, obj);

            obj = new ExtFileUpload("fileUpload", "absolute", "28.32%", "274", null, "19", "65.53%", null, this);
            this.addChild(obj.name, obj);


            
            // Layout Functions
            //-- Default Layout
            obj = new Layout("default", "", 1024, 768, this,
            	//-- Layout function
            	function(p) {
            		p.set_classname("Sample");
            		p.set_titletext("SampleForm");

            	}
            );
            this.addLayout(obj.name, obj);


            
            // BindItem Information

            
            // Remove Reference
            obj = null;
        };
        

        
        // User Script
        this.registerScript("Sample.xfdl", function() {

        this.btnSearch_onclick = function(obj,e)
        {
        	trace("조회");
        }

        
        this.fn_search = function()
        {
        	var sSvcID        	= "search";                    
            var sController   	= "selectCodeGroupList.do";
            
        	var sInDatasets   	= "ds_search=ds_search";
        	var sOutDatasets  	= "ds_codeGroupList=dsGroupCode ds_codeList=dsCode";
        	
        	var sArgs = "";	

        	this.ds_search.clearData();
            var rowIdx = this.ds_search.addRow();
        	// 조회조건(Condition)
        	if (this.div_search.cmb_searchCondition.value == 0)
        	{
        		this.ds_search.setColumn(rowIdx, "groupNm", this.div_search.edt_searchKeyword.value);
        	}
        	else if (this.div_search.cmb_searchCondition.value == 1)
        	{
        		this.ds_search.setColumn(rowIdx, "groupCd", this.div_search.edt_searchKeyword.value);
        	}
        	trace("aaaaa"  + sController);
        	Ex.core.tran(this,sSvcID, sController, sInDatasets, sOutDatasets, sArgs); 
        }
        this.Calendar02_oneditclick = function(obj,e)
        {
        	
        }
        
        });


        
        // Regist UI Components Event
        this.on_initEvent = function()
        {
            this.GroupBox00.addEventHandler("onlbuttondown", this.GroupBox00_onlbuttondown, this);
            this.btnSearch.addEventHandler("onclick", this.btnSearch_onclick, this);
            this.Static00.addEventHandler("onclick", this.Static00_onclick, this);
            this.Calendar02.addEventHandler("oneditclick", this.Calendar02_oneditclick, this);
            this.Static09.addEventHandler("onclick", this.Static00_onclick, this);
            this.Button01.addEventHandler("onclick", this.Button00_onclick, this);
            this.Button02.addEventHandler("onclick", this.Button00_onclick, this);
            this.Button03.addEventHandler("onclick", this.Button00_onclick, this);
            this.Button04.addEventHandler("onclick", this.Button00_onclick, this);
            this.Button06.addEventHandler("onclick", this.Button00_onclick, this);
            this.Button07.addEventHandler("onclick", this.Button00_onclick, this);

        };

        this.loadIncludeScript("Sample.xfdl");

       
    };
}
)();
